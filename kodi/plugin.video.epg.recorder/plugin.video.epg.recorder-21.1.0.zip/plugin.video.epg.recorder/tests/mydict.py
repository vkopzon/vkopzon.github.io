#!/usr/local/bin/python

class mydict(dict):
    def saysome(self, string):
        print (string)
