# -*- coding: utf-8 -*-
import xbmc

def log(v, type=xbmc.LOGERROR):
    xbmc.log('[EPGRECORDER]: '+repr(v), type)

def main():
    if xbmc.getCondVisibility('String.IsEqual(ListItem.DBType,movie) + !String.IsEmpty(ListItem.DBID)'):
        xbmc.executebuiltin('RunScript(script.embuary.info,call=movie,dbid=%s)' % xbmc.getInfoLabel('ListItem.DBID'))

    elif xbmc.getCondVisibility('String.IsEqual(ListItem.DBType,movie)'):
        xbmc.executebuiltin('RunScript(script.embuary.info,call=movie,query=\'"%s"\',year=%s)' % (xbmc.getInfoLabel('ListItem.OriginalTitle'),xbmc.getInfoLabel('ListItem.Year')))

    elif xbmc.getCondVisibility('String.IsEqual(ListItem.DBType,tvshow) + !String.IsEmpty(ListItem.DBID)'):
        xbmc.executebuiltin('RunScript(script.embuary.info,call=tv,dbid=%s)' % xbmc.getInfoLabel('ListItem.DBID'))

    elif xbmc.getCondVisibility('String.IsEqual(ListItem.DBType,tvshow)'):
        xbmc.executebuiltin('RunScript(script.embuary.info,call=tv,query=\'"%s"\',year=%s)' % (xbmc.getInfoLabel('ListItem.TVShowTitle'),xbmc.getInfoLabel('ListItem.Year')))

    elif xbmc.getCondVisibility('String.IsEqual(ListItem.DBType,episode) | String.IsEqual(ListItem.DBType,season)'):
        xbmc.executebuiltin('RunScript(script.embuary.info,call=tv,query=\'"%s"\')' % xbmc.getInfoLabel('ListItem.TVShowTitle'))

    elif xbmc.getCondVisibility('String.IsEqual(ListItem.DBType,actor)'):
        xbmc.executebuiltin('RunScript(script.embuary.info,call=person,query=\'"%s"\')' % xbmc.getInfoLabel('ListItem.Label'))

    else:
        log(('Calling embuary.info', xbmc.getInfoLabel('ListItem.Label'), xbmc.getInfoLabel('ListItem.Year') ))
        xbmc.executebuiltin('RunScript(script.embuary.info,call=movie,query=\'"%s"\',year=%s)' % (xbmc.getInfoLabel('ListItem.Label'),xbmc.getInfoLabel('ListItem.Year')))

        
if __name__ == '__main__':
    main()
