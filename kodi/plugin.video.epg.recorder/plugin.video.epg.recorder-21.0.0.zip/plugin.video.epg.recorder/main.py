# -*- coding: utf-8 -*-

import xbmcgui
import xbmcplugin
import xbmcvfs
import xbmcaddon

from datetime import datetime, timedelta, tzinfo, timezone
from language import get_string
#from struct import *
from urllib.parse import urlencode, parse_qsl
from multiprocessing.connection import Client
from timeit import default_timer as timer

import urllib
import urllib.parse
import calendar
import ctypes
import json
import os, os.path
import platform
import re
import sqlite3
import sys
import time
import pickle
#import glob
#import io
#import shutil
#import threading


try:
    from urllib.parse import quote, quote_plus, unquote_plus
except ImportError:
    from urllib import quote, quote_plus, unquote_plus

################################################################################

def named_storage(dtype=dict(), name=None):

    if not ((type(dtype) is dict) or (type(dtype) is list)):
        log(("bad dtype exp: dict or list"), type(dtype))
        return

    class st_class(type(dtype)):
        name  = None
        def load(self, name):
            st_class.name = name
            tmp = xbmcaddon.Addon().getSettingString(name)
            if tmp != "":
                tmp = json.loads(tmp)
                if type(tmp) is dict:
                    self.update(tmp)
                else:# list
                    self.extend(tmp)
            
        def store(self, data=None):
            if data:
                xbmcaddon.Addon().setSettingString(id=st_class.name, value=json.dumps(data))
            else:
                xbmcaddon.Addon().setSettingString(id=st_class.name, value=json.dumps(self))

        def reset(self):
            self.clear()
            self.store()

        def dump (self, fname, readable=False):
            with xbmcvfs.File(fname, 'w') as f:
                if readable:
                    json.dump(self, f, indent=4, ensure_ascii=False)
                else:
                    json.dump(self, f)
            f.close()

    ref = st_class()
    ref.load(name)

    return ref

        
################################################################################

# Get the plugin url in plugin:// notation.
__url__ = sys.argv[0]
# Get the plugin handle as an integer number.
__handle__ = int(sys.argv[1])
xbmcplugin.setContent(__handle__, 'movies')

################################################################################
# Global controls:
REC_ENABLE = 1
CREATE_NFO = 1
#
################################################################################

EPGDB          = xbmcvfs.translatePath('special://database/Epg16.db')
CHANNELDB      = xbmcvfs.translatePath('special://database/TV40.db')
NFO_SUFFIX     = '.nfo'
REC_SUFFIX     = '.ts'
POS_SUFFIX     = '.pos'
IMG_LIB_FNAME  = 'image_lib.json'
CHANNELS_FNAME = 'channels.json'
ARCHIVE_LENGTH = 7

RECENT_ST  = '__RECENT__'
PLAYING_ST = '__PLAYING__'
RECORD_ST  = '__RECORD__'
WATCHED_ST = '__WATCHED__'
#ALL_RECORDINGS = '__ALLRECORDS__'
LIST_STORAGES   = [RECENT_ST]
DICT_STORAGES   = [WATCHED_ST, RECORD_ST, PLAYING_ST]

CHANNEL_SKIPLIST = xbmcaddon.Addon().getSettingString('channel_skiplist').split(',')

UTC_ADJUST = timedelta(hours = xbmcaddon.Addon().getSettingInt('timeshift'))
if platform.system() == 'Windows':
    UTC_ADJUST = UTC_ADJUST + timedelta(hours=1)

def addon_id():
    return xbmcaddon.Addon().getAddonInfo('id')

def log(v, type=xbmc.LOGERROR):
    xbmc.log('[EPGRECORDER]: '+repr(v), type)


def get_icon_path(icon_name):
    return "special://home/addons/%s/resources/img/%s.png" % (addon_id(), icon_name)


def remove_formatting(label):
    label = re.sub(r"\[/?[BI]\]", '', label, flags=re.I)
    label = re.sub(r"\[/?COLOR.*?\]", '', label, flags=re.I)
    return label


def delete(path):
    dirs, files = xbmcvfs.listdir(path)
    for file in files:
        xbmcvfs.delete(path+file)
    for dir in dirs:
        delete(path + dir + '/')
    xbmcvfs.rmdir(path)

def rmdirs(path):
    path = xbmcvfs.translatePath(path)
    dirs, files = xbmcvfs.listdir(path)
    for dir in dirs:
        rmdirs(os.path.join(path,dir))
    xbmcvfs.rmdir(path)


def find(path):
    path = xbmcvfs.translatePath(path)
    all_dirs = []
    all_files = []
    dirs, files = xbmcvfs.listdir(path)
    for file in files:
        file_path = os.path.join(path,file)
        all_files.append(file_path)
    for dir in dirs:
        dir_path = os.path.join(path,dir)
        all_dirs.append(dir_path)
        new_dirs, new_files = find(os.path.join(path, dir))
        for new_dir in new_dirs:
            new_dir_path = os.path.join(path,dir,new_dir)
            all_dirs.append(new_dir_path)
        for new_file in new_files:
            new_file = os.path.join(path,dir,new_file)
            all_files.append(new_file)
    return all_dirs, all_files

def check_has_db_filled_show_error_message_ifn(db_cursor):
    table_found = db_cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='streams'").fetchone()
    if not table_found:
        xbmcgui.Dialog().notification("IPTV Recorder", get_string("Database not found"))
        return False
    return True


def xml2local(xml):
    #TODO combine
    return utc2local(xml2utc(xml))

def utc2local(utc):
    timestamp = calendar.timegm(utc.timetuple())
    local = datetime.fromtimestamp(timestamp)
    return local.replace(microsecond=utc.microsecond)

def utc2utc(utc):
    timestamp = calendar.timegm(utc.timetuple())
    local = datetime.fromtimestamp(timestamp)
    return local
    
def str2dt(string_date):
    format ='%Y-%m-%d %H:%M:%S'
    try:
        res = datetime.strptime(string_date, format)
    except TypeError:
        res = datetime(*(time.strptime(string_date, format)[0:6]))
    return utc2local(res)

def total_seconds(td):
    return int((td.microseconds + (td.seconds + td.days * 24 * 3600) * 10**6) / 10**6)

def hhmmss2seconds(t):
    seconds = 0
    tl = t.split(':')
    #log(tl)
    if len(tl) == 1:
        seconds += int(tl[0])
    if len(tl) == 2:
        seconds += int(tl[0])*60
        seconds += int(tl[1])
    if len(tl) == 3:
        seconds += int(tl[0])*60*60
        seconds += int(tl[0])*60
        seconds += int(tl[1])
    return seconds

def windows():
    if os.name == 'nt':
        return True
    else:
        return False

def refresh():
    containerAddonName = xbmc.getInfoLabel('Container.PluginName')
    AddonName = xbmcaddon.Addon().getAddonInfo('id')
    if (containerAddonName == AddonName):
        xbmc.executebuiltin('Container.Refresh')

def timestamp2datetime(ts):
    return datetime.fromtimestamp(ts)


def time2str(t):
    return "%02d:%02d" % (t.hour,t.minute)


def str2time(s):
    return datetime.time(hour=int(s[0:1],minute=int(s[3:4])))

def record_from_epg_player(caller):
    if not xbmcaddon.Addon().getSettingBool('record'):
        return

    title = xbmc.getInfoLabel('VideoPlayer.Title')
    log((caller))
    try:
        chname = caller['chname']
        channels = get_channel_table()
        url  = channels[chname]['url']
        conn = sqlite3.connect(EPGDB, detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
        c = conn.cursor()
        idEpg = c.execute('SELECT idEpg FROM epg WHERE sName=?',(chname,)).fetchone()
        start, stop, plot, thumbnail, sGenre, year = c.execute('SELECT iStartTime, iEndTime, sPlot, sIconPath, sGenre, iYear FROM epgtags WHERE sTitle=? AND idEpg=? AND iEndTime<?',(title,idEpg[0],int(datetime.now().timestamp()))).fetchone()
    except:
        xbmcgui.Dialog().notification("Connot be recorded.", 'Future progarm? (bad channel)',
                                      xbmcgui.NOTIFICATION_ERROR, 10000)
        return

    conn.commit()
    conn.close()
    before = xbmcaddon.Addon().getSettingInt('start_offset')
    after  = xbmcaddon.Addon().getSettingInt('stop_offset')
    start  = datetime.utcfromtimestamp(start)
    stop   = datetime.utcfromtimestamp(stop)
    my_start = start - UTC_ADJUST - timedelta(minutes=before)
    my_stop  = stop - UTC_ADJUST + timedelta(minutes=after)
    length   = str(total_seconds(my_stop - my_start))
    my_start = str(my_start.replace(tzinfo=timezone.utc).timestamp())
    my_stop  = str(my_stop.replace(tzinfo=timezone.utc).timestamp())
    if not plot:
        plot = 'plot'
    if not thumbnail:
        thumbnail='thumbnail'
    # Create playing item:
    item=dict()
    item['chname']=chname
    item['url']=url
    item['title']=title
    item['my_start']=my_start
    item['my_stop']=my_stop
    item['length']=length
    item['plot']=plot
    item['picon']=thumbnail
    item['poster']=thumbnail
    item['thumbnail']=thumbnail
    item['genre']=sGenre
    item['ptitle']=purify_title(title)
    item['position'] = hhmmss2seconds(xbmc.getInfoLabel('PVR.EpgEventElapsedTime'))
    item['year'] = year
    tmp = item
    add2history(item)

    playing_item = named_storage(name=PLAYING_ST)
    playing_item.store(item)
    record_currently_playing_item()
    monitor_player_state(item.copy(), context='record')

def add2history(prog):
    #log(('adding prog',prog))

    MAX_RECENTLY_PLAYED = xbmcaddon.Addon().getSettingInt('max_recent')
    recent = named_storage(dtype=list(), name=RECENT_ST)
    rec_folder = xbmcvfs.translatePath(xbmcaddon.Addon().getSettingString('rec_folder'))

    i=0
    for e in recent:
        #log(('testing: ',e))
        if e['title'] == prog['title']:
            recent.pop(i)
            #log(('removing element', prog))
        i+=1
    while len(recent) > MAX_RECENTLY_PLAYED:
        p = recent.pop()
        fname = rec_folder + prog['ptitle'] + POS_SUFFIX
        #log(('poping from recent',fname))
        xbmcvfs.delete(fname)

    recent.insert(0, prog)
    recent.store()
    # if xbmcaddon.Addon().getSettingBool('record'):
    #     ffrom = xbmcvfs.translatePath(plugin.storage_path + 'recently_played')
    #     fto   = xbmcvfs.translatePath(get_db_folder() + 'recently_played')
    #     #log(('storage:',ffrom, fto))
    #     xbmcvfs.copy(ffrom, fto)

    return

def history(params):
    db = named_storage(dtype=list(), name=RECENT_ST)

    items = []
    for e in db:
        position = e.get('position', 0)
        year = e.get('year', 0)
        li = xbmcgui.ListItem(
            label=e['title'],
            offscreen = True
        )
        li.setProperty('IsPlayable','true')
        path = build_url({
            'call':'play_by_url', 'chname':e['chname'], 'url':e['url'], 'title':e['title'],
            'my_start':e['my_start'], 'my_stop':e['my_stop'], 'length':e['length'],
            'poster':e['poster'],'plot':e['plot'], 'position':str(position),
            'thumbnail':e['thumbnail'], 'genre':e['genre'], 'year':year
        })
        infotagvideo = li.getVideoInfoTag()
        #infotagvideo.setTitle(e['title'])
        #infotagvideo.setSortTitle(e['title'])
        infotagvideo.setPlot('[COLOR grey]'+ str(year)+" "+e['genre']+"[/COLOR]\n"+e['plot'])
        #infotagvideo.setGenres(split_into_list(categories))
        infotagvideo.setOriginalTitle(e['title'])
        #infotagvideo.setDirectors(split_into_list(director))
        #infotagvideo.setArtists(split_into_list(cast))
        infotagvideo.setYear(int(year))
        #infotagvideo.setMediaType('movie')

        li.setArt({
            "icon": e['thumbnail'],
            "landscape": e['thumbnail'],
            "clearart": e['thumbnail'],
            "clearlogo": e['thumbnail'],
            "thumb": e['thumbnail'],
            "poster": e['poster'],
            "banner": e['thumbnail'],
            "fanart":e['thumbnail']
        })

        #li.set_property('thumbnail', e['thumbnail'])
        li.setProperties({
            'StartOffset':e.get('position', 0),
            'StartPercent':100*float(position)/float(e['length']),
        })

        items.append((path, li))

    xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_TITLE_IGNORE_THE)
    return items
    
def category(params):
    category = params['title']
    hide_watched = eval(params['hide_watched'])
    tsubset = params['tsubset']
    programmes = []
        
    if not len(programmes):
    
        conn = sqlite3.connect(EPGDB, detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
        c = conn.cursor()

        #programmes = c.execute('SELECT idEpg, sTitle, iStartTime, iEndTime, iYear , sPlot , sGenre, sIconPath, sCast, sDirector FROM epgtags WHERE sGenre LIKE ? AND iEndTime<? ORDER BY iYear DESC, iStartTime DESC',("%"+category+"%", int(datetime.now().timestamp()))).fetchall()
        programmes = c.execute(
            'SELECT idEpg, sTitle, iStartTime, iEndTime, iYear , sPlot , sGenre, sIconPath, sCast, sDirector \
            FROM epgtags \
            WHERE sGenre LIKE ? AND iEndTime<? AND iStartTime>? ORDER BY iYear DESC, sTitle DESC, iStartTime DESC',
            ("%"+category+"%", int(datetime.now().timestamp()), int((datetime.now()-timedelta(days=ARCHIVE_LENGTH)).timestamp()))
        ).fetchall()
        # sTitle should be @ position 1 to uniqify later by title
        # sort by DESC order to correctly uniqify for latest programm

        conn.commit()
        conn.close()
    else:
        log('programs used from cache')

    return (make_list(programmes, mode='movie', hide_watched=hide_watched, scroll=True))


def sports(params):
    items = []

    sport_categories = xbmcaddon.Addon().getSettingString('sport_groups')
    #log(sport_categories)
    sport_categories = sport_categories.split(',')
    
    is_folder = True
    for cat in sport_categories:
        #log(cat)
        cat = cat.split(':')

        li = xbmcgui.ListItem(
            label = cat[1],
        )
        url = build_url({'call':'sport', 'text':cat[0]})
        #li.setArt({"thumb": get_icon_path('sport')})
        items.append((url, li, is_folder))

    return items


def sport(params):

    programmes = []
    texts = params['text'].split('|')

    conn = sqlite3.connect(EPGDB, detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    c = conn.cursor()

    for text in texts:
        #log('extending by %s' % text)
        progs = c.execute('SELECT idEpg, sTitle, iStartTime, iEndTime, iYear , sPlot , sGenre, sIconPath, sCast, sDirector \
                           FROM epgtags WHERE sTitle LIKE ? AND iEndTime<? ORDER BY iStartTime DESC, iStartTime DESC',
                          ("%"+text+"%", int(datetime.now().timestamp()))).fetchall()
        #progs = c.execute('SELECT idEpg, sTitle, iStartTime, iEndTime, iYear , sPlot , sGenre, sIconPath, sCast, sDirector FROM epgtags WHERE sTitle LIKE ? ORDER BY iYear DESC, iStartTime DESC',
        #                           ("%"+text+"%", )).fetchall()
        # sTitle should be @ position 1 to uniqify later by title
        # sort by DESC order to corrctly uniqify for latest programm
        #log(programmes)
        if len(progs) > 0:
            #log('extending from %s by %s' % (text, progs))
            programmes.extend(progs)
        
    conn.commit()
    conn.close()

    return make_list(programmes, mode='sport', hide_watched=False, scroll=True)


def uniqify_programs(programmes):
    res = []
    skip_title = ""
    
    for p in programmes:
        #log(p)
        if p[1] == skip_title:
            #log("skipping " + p[1])
            continue
        else:
            skip_title = p[1]
            res.append(p)
            #log("appending " + p[1])
            
    #log(res)
    return res

def get_channel_table():
    channels = {}
    dir = xbmcaddon.Addon().getSettingString('db_folder')
    json_file = dir+CHANNELS_FNAME
    if xbmcvfs.exists(json_file):
        #log(('Loading channels file', json_file))
        channels = xbmcvfs.File(json_file).read()
        channels = json.loads(channels)
        #log(('Chnnels loaded!', json_file))
        #log((channels['Viju+ Megahit HD']))
    else:
        log('Unable to load %s' % json_file)
    return channels

def is_series(title):
    return re.search("сезон", title) and re.search("серия", title)

def make_list(programmes, mode, hide_watched, scroll=False):
    conn = sqlite3.connect(EPGDB)
    c = conn.cursor()
    #log('starting make_list')
    dir = xbmcaddon.Addon().getSettingString('db_folder')
    json_file = dir+IMG_LIB_FNAME
    if xbmcvfs.exists(json_file):
        #log(('Loading image lib', json_file))
        img_lib = xbmcvfs.File(json_file).read()
        img_lib = json.loads(img_lib)

    channels = get_channel_table()
    items = []
    skip_title = ""

    start_offset = xbmcaddon.Addon().getSettingInt('start_offset')
    start_offset_str_in_sec = str(start_offset * 60)
    stop_offset = xbmcaddon.Addon().getSettingInt('stop_offset')
    watched = named_storage(name=WATCHED_ST)

    index = 1
    total_items = len(programmes)
    opt_show_watched = xbmcaddon.Addon().getSettingBool('show_watched')
    for p in programmes:
        #timerstart = timer()
        idEpg, title, start, stop, year, description, categories, thumbnail, cast, director = p

        #skip duplicated programm:
        #  assumption: list is ordered by title (by sql select), so all duplicates are consequtive
        if (title == skip_title or is_series(title)) and mode == 'movie':
            #log("Skipping " + p[1])
            continue
        else:
            skip_title = title

        if mode == 'sport':
            categories = 'sport'

        entry = title+str(year)
        if entry in watched:
            item_watched = True
            #log(('item is watched', title))
        else:
            item_watched = False
            

        if not opt_show_watched and hide_watched and item_watched:
            #log(('skipping: ', title, hide_watched, item_watched))
            continue

        if not description:
            description = 'none'

        chname = c.execute('SELECT sName FROM epg WHERE idEPG=?',(idEpg,) ).fetchone()
        chname = str(chname[0])

        if chname in CHANNEL_SKIPLIST:
            continue
        
        if chname in channels:
            url    = channels[chname]['url']
            picon  = channels[chname]['pcon']
        else:
            log(('cannot resolve channel: ', chname, p))
            continue

        start  = datetime.utcfromtimestamp(start)
        stop   = datetime.utcfromtimestamp(stop)
        #log(('listing:', chname, title, start, categories, picon, description))

        episode = " "
        color = ""
        if item_watched:
            stitle = "[COLOR grey]%s[/COLOR]" % (title)
        else:
            stitle = title

        #label = "%02d:%02d-%02d:%02d [COLOR grey]%s/%s[/COLOR] %s %s %s%s (%s)" % (start.hour, start.minute, stop.hour, stop.minute, start.day,
        #                                                                           start.month, channelname_label, categories_label, CR, stitle, year)

        dtl = str(get_remaining_time(start).days)
        context_items = []
        #log(UTC_ADJUST)
        my_start = start - UTC_ADJUST - timedelta(minutes=start_offset)
        my_stop  = stop - UTC_ADJUST + timedelta(minutes=stop_offset)
        length   = str(total_seconds(my_stop - my_start))
        my_start = str(my_start.replace(tzinfo=timezone.utc).timestamp())
        my_stop  = str(my_stop.replace(tzinfo=timezone.utc).timestamp())
        #now = str(int(datetime.now().timestamp()))

        if not thumbnail:
            thumbnail = picon
        poster = thumbnail

        #log((chname, url, title, my_start, my_stop, length, picon, thumbnail, description))
        if title in img_lib:
            poster    = img_lib[title][0]
            thumbnail = poster
            #log('overriding %s poster %s' % (title, poster))
            if len(img_lib[title]) > 1:
                thumbnail = img_lib[title][1]
                #log('overriding %s thumbnail %s' % (title, thumbnail))

        li = xbmcgui.ListItem(
            label=stitle,
            #label2=label,
            offscreen = True,
        )
        # if index == 1:
        #     li.select(True)
        li.setProperty('IsPlayable','true')
        path = build_url({'call':'play_by_url', 'chname':chname, 'url':url, 'title':title, 'my_start':my_start,
                          'my_stop':my_stop, 'length':length, 'poster':poster, 'position':'0',
                          'plot':description, 'thumbnail':thumbnail, 'genre':categories, 'year':year})
        infotagvideo = li.getVideoInfoTag()
        #infotagvideo.setTitle(label);
        infotagvideo.setSortTitle(title);
        infotagvideo.setGenres(split_into_list(categories));
        infotagvideo.setOriginalTitle(title);
        infotagvideo.setDirectors(split_into_list(director));
        infotagvideo.setArtists(split_into_list(cast));
        if mode == 'sport':
            infotagvideo.setPlot('[COLOR grey]'+" {"+dtl+"}[/COLOR]\n")
        else:
            infotagvideo.setPlot('[COLOR grey]'+ str(year)+" {"+dtl+"}  "+categories+"[/COLOR]\n"+description)
            infotagvideo.setYear(year);
            #infotagvideo.setMediaType('movie');
            
        li.setArt({
            "icon": thumbnail,
            "landscape": thumbnail,
            "clearart": thumbnail,
            "clearlogo": thumbnail,
            "thumbnail": thumbnail,
            "poster": poster,
            "banner": thumbnail,
            "fanart": thumbnail
        })

        li.addContextMenuItems([
            ("[COLOR green]%s[/COLOR]" % "Mark as watched",
             'RunPlugin(%s)' % (build_url({'call':'mark_as_watched', 'title':title, 'date':year}))),
            ("Mark as unwatched",
             'RunPlugin(%s)' % (build_url({'call':'mark_as_unwatched', 'title':title, 'date':year})))
        ])
        
        items.append((path, li, False,))
        # log(('adding item:', index))
        
        # if index == 50:
        #     log(('First endOfDirectory called', total_items))
        #     xbmcplugin.addDirectoryItems(__handle__, items=items)
        #     #xbmcplugin.endOfDirectory(__handle__, updateListing=True, cacheToDisc=True)
        #     #items=[]
        # elif index % 50 == 0:
        #     log(('call endOfDirectory for index:', index))
        #     xbmcplugin.addDirectoryItems(__handle__, items=items)
        #     #xbmcplugin.endOfDirectory(__handle__, updateListing=True, cacheToDisc=True)
        #     #items=[]

        index += 1
        # timerend = timer()
        # log(('elapsed time:', timedelta(seconds=timerend-timerstart)))


    # xbmcplugin.addDirectoryItems(__handle__, items=items)
    # xbmcplugin.endOfDirectory(__handle__, updateListing=False, cacheToDisc=True)
    # log('finished make_list')

    conn.commit()
    conn.close()
 
    #xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_NONE)
    #xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_TITLE_IGNORE_THE)
 
    return items

def split_into_list(string):
    list = string.split(', ')
    return list

def mark_as_watched(params):
    title = params['title']
    date  = params['date']
    log(('Watched: ', title+date))
    watched = named_storage(name=WATCHED_ST)
    entry = title+date
    watched[entry] = True
    watched.store()
    refresh()

def mark_as_unwatched(params):
    title = params['title']
    date  = params['date']
    log(('UnWatched: ', title+date))
    watched = named_storage(name=WATCHED_ST)
    entry = title+date
    if entry in watched:
        #log(('found', entry))
        del watched[entry]
    watched.store()
    refresh()
    
def play_by_url(item):
    item['ptitle']=purify_title(item['title'])

    add2history(item.copy())

    now = str(int(datetime.now().timestamp()))
    path = item['url'] + "?utc=" + item['my_start'] + "&lutc=" + now

    playing_item = named_storage(name=PLAYING_ST)
    playing_item.store(item)

    li = xbmcgui.ListItem(path=path)
    li.setProperties({
        'inputstream': 'inputstream.ffmpegdirect',
        'inputstream.ffmpegdirect.catchup_buffer_start_time': item['my_start'],
        'inputstream.ffmpegdirect.catchup_buffer_end_time': item['my_stop'],
        'inputstream.ffmpegdirect.catchup_buffer_offset': item['position'], #start_offset_str_in_sec,   -doesn't work for small values?
        'inputstream.ffmpegdirect.catchup_granularity': str(1),
        'inputstream.ffmpegdirect.catchup_terminates': 'true',
        'inputstream.ffmpegdirect.catchup_url_format_string':
        item['url'] + xbmcaddon.Addon().getSettingString('catchup_url_format_string'),
        'inputstream.ffmpegdirect.default_url': item['url'],
        'inputstream.ffmpegdirect.is_realtime_stream': 'true',
        'inputstream.ffmpegdirect.manifest_type': 'hls',
        'inputstream.ffmpegdirect.playback_as_live': 'false',
        'inputstream.ffmpegdirect.stream_mode': 'catchup',
        #'inputstream.ffmpegdirect.timezone_shift': xbmcaddon.Addon().getSettingString('timezone.shift'),
    })
    xbmcplugin.setResolvedUrl(__handle__, True, listitem=li)
    monitor_player_state(item.copy(), context='play')
    
    
def my_play(path):
    xbmc.Player().play(path)

    
def purify_filename(fname):
    fname = re.sub(r'(?!%s)[^\w\-_\.]', '', fname)
    fname = re.sub('\.+', '.', fname)
    fname = re.sub('^\.+', '', fname)
    return fname

def purify_title(title):
    title = re.sub('Х/ф ', '', title)
    title = re.sub('М/ф ', '', title)
    title = re.sub('"', '', title)
    title = re.sub(':', '', title)
    title = re.sub('/', '_', title)
    title = re.sub(r'\\', '_', title)
    title = re.sub('(\.\s*$)', '', title)
    return title

def get_raw_dict_from_ts(ts):
    d = dict()
    d.update(ts.items())
    return d

def record_currently_playing_item(params=dict()):
    # can be called directly from player (see Variables.xml) or from record_from_epg_player function.
    if not xbmcaddon.Addon().getSettingBool('record'):
        return
    
    item = named_storage(name=PLAYING_ST)
    log(("actual recording:", item['chname'], item['url'], item['title'],
         item['my_start'], item['length'], item['genre']))
    rec_folder = xbmcvfs.translatePath(xbmcaddon.Addon().getSettingString('rec_folder'))

    if REC_ENABLE:
        fname = rec_folder + item['ptitle'] + REC_SUFFIX
        # allrecs = named_storage(dtype=list(), name=ALL_RECORDINGS)
        # if not len(allrecs):
        #     allrecs.append({}) # empty recording list
        # catalog = allrecs[0]
        if xbmcvfs.exists(fname): # or catalog.get(item['ptitle'], False):
            xbmcgui.Dialog().notification("EPG Recorder - Already Recorded", item['title'],
                                          xbmcgui.NOTIFICATION_INFO, 5000)
        else:
            item2send = dict()
            #icopy = get_raw_dict_from_ts(item)
            for key in ('url','ptitle','my_start','length'): # minimizing object to be sent (limit 256B)
                item2send[key] = item[key]
            item2send['now'] = str(datetime.now().timestamp())
            conn = Client((xbmcaddon.Addon().getSettingString('recorder_ip'),
                           xbmcaddon.Addon().getSettingInt('recorder_port')),
                          authkey=bytes(xbmcaddon.Addon().getSettingString('recorder_pass'), 'UTF=8'))
            conn.send(pickle.dumps(item2send))
            conn.send('close connection')
            conn.close()
            
            xbmcgui.Dialog().notification("Recoding Started", item['chname']+': '+item['title'],
                                          xbmcgui.NOTIFICATION_INFO, 5000, sound=False)
            fresh_record = named_storage(name=RECORD_ST)
            fresh_record[item['title']] = True # This is to start first play from recording offset
            fresh_record.store()

            if CREATE_NFO:
                fname = rec_folder + item['ptitle'] + NFO_SUFFIX
                # if 'position' in item:
                #     position = item['position']
                # else:
                position = xbmc.Player().getTime()
                #log('creating NFO_ini with position %s' % position)
                f = xbmcvfs.File(fname, 'w')
                item['progress'] = 100*position/float(item['length'])
                json.dump(item, f)
                f.close()
                # catalog[item['ptitle']] = len(catalog)
                # allrecs.append(item)
                # allrecs.store()

    return

def get_remaining_time(startime):
    return timedelta(days=7) - (datetime.now() - utc2local(startime))


def monitor_player_state(item, context='play'):
    rec_folder = xbmcvfs.translatePath(xbmcaddon.Addon().getSettingString('rec_folder'))
    title = item['title']
    length = item['length']
    position = 0
    player = xbmc.Player()
    monitor = xbmc.Monitor()      

    ok_to_update_position = False
    
    wait_time = 3
    wait_step = 1
    if context=='play':
        # wait few secs for player to start. In 'record' conext it is called from player started
        # without play_by_url function, so monitor is inactive
        while not player.isPlaying() and wait_time > 0:
            if monitor.waitForAbort(wait_step): # Sleep/wait for abort for 5 second.
                xbmc.log("Player monitor thread stopped by abort." , xbmc.LOGERROR)
                break # Abort was requested while waiting. Exit the while loop.
            wait_time -= wait_step

        if not player.isPlaying():
            return              # as no player has started at all
        #log('Player monitoring ok. Waited player for %d sec' % (5 - wait_time))

    while not monitor.abortRequested():
        if player.isPlaying():
            ok_to_update_position = True
            if context=='play':
                position = player.getTime()
            else:
                position = hhmmss2seconds(xbmc.getInfoLabel('PVR.EpgEventElapsedTime'))
            #xbmc.log("Playing position: %f" % position, xbmc.LOGERROR)

            if monitor.waitForAbort(5): # Sleep/wait for abort for 5 second.
                xbmc.log("Autostop addon service stopped." , xbmc.LOGERROR)
                break # Abort was requested while waiting. Exit the while loop.
        else:
            break               # Abort on recorder player stop

    #log("Playback of %s stopped at %f." % (item['title'], position))
    fname = rec_folder + item['ptitle'] + NFO_SUFFIX
    if context=='record' or xbmcvfs.exists(fname):
        # when file exists in 'play' content it means that recoder is invoked not by EPG player
        if CREATE_NFO:
            # well, if we get there playback stopped during recording, so we will update the NFO with
            # correct start offset
            #log('creating NFO with position %s' % position)
            f = xbmcvfs.File(fname, 'w')
            item['progress'] = 100*position/float(item['length'])
            json.dump(item, f)
            f.close()
            # allrecs = named_storage(dtype=list(), name=ALL_RECORDINGS)
            # catalog = allrecs[0]
            # idx = catalog[item['ptitle']]
            # allrecs[idx]=item
            # allrecs.store()

    if ok_to_update_position:
        hist = named_storage(dtype=list(), name=RECENT_ST)
        hist[0]['position'] = int(position)
        hist.store()

        # fname = rec_folder + item['ptitle'] + POS_SUFFIX
        # f = xbmcvfs.File(fname, 'w')1
        # f.write('%d' % int(position))
        # f.close()
        #log('updating position in recently_played entry %s by %f' % (item['ptitle'], position))
        

def focus(i):
    #TODO find way to check this has worked (clist.getSelectedPosition returns -1)
    xbmc.sleep(int(xbmcaddon.Addon().getSettingString('scroll.ms') or "0"))
    #TODO deal with hidden ..
    win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    cid = win.getFocusId()
    if cid:
        clist = win.getControl(cid)
        if clist:
            try: clist.selectItem(i)
            except: pass

def categories(params):
    #TODO: take only Kino channels. Currently no genres in others :)
    hide_watched = eval(params['hide_watched'])
    items = []

    conn = sqlite3.connect(EPGDB)
    c = conn.cursor()
    titles = c.execute("SELECT DISTINCT sGenre FROM epgtags ORDER BY sGenre").fetchall()
    conn.commit()
    conn.close()

    cats = set()
    for title in titles:
        programme_categories = title[0]
        cats.add(programme_categories)
        programme_categories = programme_categories.split(', ')
        for cat in programme_categories:
            if cat:
                cats.add(cat)
    cats = sorted(list(cats))
    try:
        idx = cats.index('undefined')
        cats.append(cats.pop(idx))
    except:
        pass    

    for cat in cats:
        if not cat or ',' in cat:
            continue
        label = cat
        title = cat

        li = xbmcgui.ListItem(
            label = label,
        )
        url = build_url({'call':'category', 'title':title, 'hide_watched':hide_watched, 'tsubset':'TBD'})
        is_folder = True
        #log((url, li, is_folder))
        items.append((url, li, is_folder))

    return items


def delete_recording(params):
    label = params['label']
    path  = params['path']
    if not (xbmcgui.Dialog().yesno("EPG Recorder", "[COLOR red]" + get_string("Delete Recording?") + "[/COLOR]\n" + label)):
        return
    if not xbmcvfs.delete(path):
        return
    length = int(len(REC_SUFFIX))
    xbmcvfs.delete(path[:-length]+NFO_SUFFIX)
    xbmcvfs.delete(path[:-length]+POS_SUFFIX)
    refresh()
11

def delete_all_recordings():
    result = xbmcgui.Dialog().yesno("IPTV Recorder", "[COLOR red]" + get_string("Delete All Recordings?") + "[/COLOR]")
    if not result:
        return

    dir = xbmcaddon.Addon().getSettingString('rec_folder')
    dirs, files = find(dir)
    for file in sorted(files):
        if file.endswith(REC_SUFFIX):
            success = xbmcvfs.delete(file)
            if success:
                length = int(len(REC_SUFFIX))
                json_file = file[:-length]+'.json'
                xbmcvfs.delete(json_file)

    rmdirs(dir)
    refresh()


def find_files(root):
    dirs, files = xbmcvfs.listdir(root)
    #found_files = []
    #for dir in dirs:
    #    path = os.path.join(xbmcvfs.translatePath(root), dir)
    #    found_files = found_files + find_files(path)
    file_list = []
    for file in files:
        if file.endswith(REC_SUFFIX):
            file = os.path.join(xbmcvfs.translatePath(root), file)
            file_list.append(file)
    #return found_files + file_list
        #st = xbmcvfs.Stat(file)
        #md = st.st_mtime()
        #addeddate = timestamp2datetime(md)
        #log((file, md, addeddate))
    file_list.sort(reverse=True, key=lambda x: timestamp2datetime(xbmcvfs.Stat(x).st_mtime()))
    return file_list

def recordings(params):
    rec_folder = xbmcaddon.Addon().getSettingString('rec_folder')
    db_folder  = xbmcaddon.Addon().getSettingString('db_folder')
    found_files = find_files(rec_folder)

    items = []
    starts = []
    
    fresh_record = named_storage(name=RECORD_ST)
    #log(fresh_record.raw_dict())

    # allrecs = named_storage(dtype=list(), name=ALL_RECORDINGS)
    # if not len(allrecs):
    #     allrecs.append({}) # empty recording list
    # catalog = allrecs[0]
    
    for path in found_files:
        json_file = path[:-3]+NFO_SUFFIX
        resumetime = 0
        label = os.path.splitext(os.path.basename(path))[0] # by filename
        label = unquote_plus(label)
        title = label
        plot = "Настенька, запись еще не окончилась. Ты можешь смотреть, но когда остановится - включи заново..."
        pcon = "None"
        thumbnail = pcon
        poster=""
        genre=""
        progress=0

        #log(('Recording: ', json_file))
        if xbmcvfs.exists(json_file):
            timerstart = timer()
            try:
                info = json.loads(xbmcvfs.File(json_file).read())
            except:
                log('Unable to load recording file %s' % json_file)
                continue
            # catalog[info['title']] = len(allrecs)
            # allrecs.append(info)
            # timerend = timer()
            #log(('Recording info: ', info))
            title = info.get('title')
            pcon  = info.get('pcon')
            plot  = info.get('plot')
            genre = info.get('genre')
            thumbnail = info.get('thumbnail', None)
            label     = title
            poster    = info.get('poster', None)
            progress  = info.get('progress', 0)
            year      = info.get('year', 0)
            
        # log(('elapsed time:', timedelta(seconds=timerend-timerstart)))
        li = xbmcgui.ListItem(
            label = label,
            offscreen = True
        )
        li.setProperty('IsPlayable','true')
        path = play_recording(path=path, title=title)
        
        infotagvideo = li.getVideoInfoTag()
        #infotagvideo.setTitle(title);
        #infotagvideo.setSortTitle(title);
        infotagvideo.setPlot('[COLOR grey]'+ str(year) +" "+ genre +"[/COLOR]\n"+ plot)
        infotagvideo.setGenres(split_into_list(genre));
        infotagvideo.setYear(int(year))
        #infotagvideo.setMediaType('movie');

        li.setArt({
            "icon": thumbnail,
            "landscape": thumbnail,
            "clearart": thumbnail,
            "clearlogo": thumbnail,
            "thumbnail": thumbnail,
            "poster": poster,
            "banner": thumbnail,
            "fanart":thumbnail
        })

        if title in fresh_record:
            li.setProperties({
                #'StartOffset':fresh_record[title],
                'StartPercent':progress,
            })
            #log('%s start offset adjusted to %s' % (title, progress))
            li.setInfo('video', {'playcount':1})
            
        #context_items.append((get_string("Delete All Recordings"),
        #'RunPlugin(%s)' % (plugin_url_for(plugin, delete_all_recordings))))
        li.addContextMenuItems([
            (get_string("Delete Recording"),
             'RunPlugin(%s)' % (build_url({'call':'delete_recording', 'label':label, 'path':path}))),
        ])

        items.append((path, li))

    # allrecs.store()
    xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_NONE)
    #xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_TITLE_IGNORE_THE)

    return items

def play_recording(path, title):
    fresh_record = named_storage(name=RECORD_ST)
    if title in fresh_record:
        #log("playing from saved position")
        del fresh_record[title] # so next time player will start from last position
        # storage.store(fresh_record)
        fresh_record.store()
    return (path)

    

def xml2utc(xml):
    if len(xml) == 14:
        xml = xml + " +0000"
    match = re.search(r'([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2}) ([+-])([0-9]{2})([0-9]{2})', xml)
    if match:
        year = int(match.group(1))
        month = int(match.group(2))
        day = int(match.group(3))
        hour = int(match.group(4))
        minute = int(match.group(5))
        second = int(match.group(6))
        sign = match.group(7)
        hours = int(match.group(8))
        minutes = int(match.group(9))
        dt = datetime(year, month, day, hour, minute, second)
        td = timedelta(hours=hours, minutes=minutes)
        if sign == '+':
            dt = dt - td
        else:
            dt = dt + td
        return dt
    return ''


def on_playback_stop(cur, total=1000):
    log(("on_playback_stop called", cur, total))
    return

def clear_history(params):
    db = named_storage(dtype=list(), name=RECENT_ST)
    db.reset()
    fresh_record = named_storage(name=RECORD_ST)
    fresh_record.reset()

def maintenance_index(params):
    items = []
    is_folder = True
    
    li = xbmcgui.ListItem(
        label = get_string("Dump internal storages"),
    )
    li.setArt({"thumb": get_icon_path('settings')})
    url = build_url({'call':'dump_internal_storages'})
    items.append((url, li, is_folder))

    li = xbmcgui.ListItem(
        label = get_string("Clear History and Recording positions"),
    )
    li.setArt({"thumb": get_icon_path('settings')})
    url = build_url({'call':'clear_history'})
    items.append((url, li, is_folder))
    return items

def dump_internal_storages(params):
    rec_folder = xbmcaddon.Addon().getSettingString('rec_folder')
    for storage_name in DICT_STORAGES:
        log(('Dumping named_storage:', storage_name))
        fname = rec_folder + '/' + storage_name +'.json'
        storage = named_storage(name=storage_name)
        storage.dump(fname, readable=True)
    for storage_name in LIST_STORAGES:
        log(('Dumping named_storage:', storage_name))
        fname = rec_folder + '/' + storage_name +'.json'
        storage = named_storage(dtype=list(), name=storage_name)
        storage.dump(fname, readable=True)
        
def get_free_space_mb(dirname):
    """Return folder/drive free space (in megabytes)."""
    if platform.system() == 'Windows':
        free_bytes = ctypes.c_ulonglong(0)
        ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(dirname), None, None, ctypes.pointer(free_bytes))
        return free_bytes.value / 1024 / 1024
    else:
        try:
            st = os.statvfs(dirname)
            return st.f_bavail * st.f_frsize / 1024 / 1024
        except:
            #log(dirname)
            return

def build_url(query):
    return __url__ + '?' + urllib.parse.urlencode(query)

def router(paramstring):
    listing = []
    context_items = []
    skip_listing = ['mark_as_unwatched', 'mark_as_watched', 'record_currently_playing_item', 'clear_history',
                    'record_from_epg_player', 'play_by_url', 'delete_recording', 'dump_internal_storages']

    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring[1:]))
    # Check the parameters passed to the plugin
    #log(('ROUTER:', params))
    if params:
        call_name = globals()[params['call']]
        listing = call_name(params)
        if params['call'] in skip_listing:
            return
    else:
        #main menu
        is_folder = True

        li = xbmcgui.ListItem(
            label     =  "[COLOR blue]Vlad[/COLOR]",
        )
        url = build_url({'call':'categories', 'hide_watched':True})
        li.setArt({"thumb": get_icon_path('movies')})
        listing.append((url, li, is_folder))

        li = xbmcgui.ListItem(
            label     =  "[COLOR orange]Фильмы по жанрам[/COLOR]",
        )
        url = build_url({'call':'categories', 'hide_watched':False})
        li.setArt({"thumb": get_icon_path('movies')})
        listing.append((url, li, is_folder))

        if xbmcaddon.Addon().getSettingBool('record'):
            li = xbmcgui.ListItem(
                label     =  "[COLOR green]Recordings[/COLOR]",
            )
            url = build_url({'call':'recordings'})
            li.setArt({"thumb": get_icon_path('recordings')})
            listing.append((url, li, is_folder))

        li = xbmcgui.ListItem(
            label     =  "History",
        )
        url = build_url({'call':'history'})
        li.setArt({"thumb": get_icon_path('history')})
        listing.append((url, li, is_folder))

        li = xbmcgui.ListItem(
            label     =  "Sport",
        )
        li.setArt({"thumb": get_icon_path('sport')})
        url = build_url({'call':'sports'})
        listing.append((url, li, is_folder))


        if xbmcaddon.Addon().getSettingBool('debug'):
            li = xbmcgui.ListItem(
                label     =  "",
            )
            #url = build_url({'call':'maintenance_index'})
            li.setArt({"thumb": get_icon_path('none')})
            listing.append((url, li, is_folder))

            li = xbmcgui.ListItem(
                label     =  "Maintenance",
            )
            li.setArt({"thumb": get_icon_path('settings')})
            url = build_url({'call':'maintenance_index'})
            listing.append((url, li, is_folder))

        if xbmcaddon.Addon().getSettingBool('record'):
            free = get_free_space_mb(xbmcvfs.translatePath(xbmcaddon.Addon().getSettingString('rec_folder')))
            if free:
                li = xbmcgui.ListItem(
                    label     =  "[COLOR dimgray]%d MB Free[/COLOR]" % free,
                )
                url = build_url({'call':'recordings'})
                listing.append((url, li, is_folder))
        
    # Add our listing to Kodi.
    # Large lists and/or slower systems benefit from adding all items at once via addDirectoryItems
    # instead of adding one by ove via addDirectoryItem.
    xbmcplugin.addDirectoryItems(__handle__, items=listing, totalItems=len(listing))
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(__handle__)
        

if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    router(sys.argv[2])

