from __future__ import unicode_literals
from kodi_six import xbmc, xbmcgui, xbmcaddon, xbmcvfs

import os, os.path
from datetime import datetime, timedelta, date, time

if __name__ == '__main__':

    monitor = xbmc.Monitor()
    ADDON = xbmcaddon.Addon('plugin.video.epg.recorder')
    update_needed = True
    first_cycle   = True
    
    if ADDON.getSetting('foldersync_enabled') == 'true':
        xbmc.log("[plugin.video.epg.recorder] Foldersync service started", level=xbmc.LOGINFO)

        profilePath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        xbmcvfs.mkdirs(profilePath)

        while not monitor.abortRequested():

            waitTime = int(ADDON.getSetting('update_period'))

            service_time = str(ADDON.getSetting('service_time'))
            service_time = service_time.split(':')
            #xbmc.log("%s" % service_time, level=xbmc.LOGINFO)
            current_datetime = datetime.now()
            current_date     = current_datetime.date()
            sync_time        = time(int(service_time[0]), int(service_time[1]))
            sync_datetime    = datetime.combine(current_date, sync_time)

            if first_cycle:
                first_cycle = False
                if current_datetime < sync_datetime:
                    last_update_date = current_date - timedelta(days = 1)
                else:
                    last_update_date = current_date
                xbmc.log("[plugin.video.epg.recorder.service] First time sync: %s" % last_update_date, level=xbmc.LOGINFO)
            else:
                if current_date != last_update_date and current_datetime > sync_datetime:
                    update_needed = True
                    last_update_date = current_date
                    xbmc.log("[plugin.video.epg.recorder.service] Periodic sync", level=xbmc.LOGINFO)
                else:
                    xbmc.log("[plugin.video.epg.recorder.service] Update not needed %s - %s | %s - %s" % (current_date, last_update_date, current_datetime, sync_datetime), level=xbmc.LOGINFO)

            if update_needed:
                from_dir = xbmcvfs.translatePath(str(ADDON.getSetting('from_dir')))
                skip_list = str(ADDON.getSetting('foldersync_skiplist'))
                skip_list = skip_list.split(':')
                
                dirs, files = xbmcvfs.listdir(from_dir)
                for file in files:
                    if not file in skip_list:
                        ffile = os.path.join(from_dir, file)
                        tfile = os.path.join(profilePath, file)
          
                        if xbmcvfs.copy(ffile, tfile):
                            xbmc.log("[plugin.video.epg.recorder.service] Synced: %s -> %s" % (ffile, tfile), level=xbmc.LOGINFO)
                        else:
                            xbmc.log("[plugin.video.epg.recorder.service] Failed to sync: %s -> %s" % (ffile, tfile), level=xbmc.LOGERROR)
                update_needed = False

                # if current_datetime < sync_datetime:
                #     next_update_datetime = sync_datetime
                # else:           # will do it tomorrow
                #     next_update_datetime = sync_datetime + timedelta(days = 1)
                # td = next_update_datetime - current_datetime
                # waitTime = td.total_seconds()
                
                xbmc.log("[plugin.video.epg.recorder.service] Next sync in %s sec" % waitTime, level=xbmc.LOGINFO)

            if monitor.waitForAbort(waitTime) or  ADDON.getSetting('foldersync_enabled') == 'false':
                break

    xbmc.log("[plugin.video.epg.recorder] Foldersync service stopped", level=xbmc.LOGINFO)
