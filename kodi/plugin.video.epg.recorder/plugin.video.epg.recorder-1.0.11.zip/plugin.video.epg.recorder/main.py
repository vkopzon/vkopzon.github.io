# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from xbmcswift2 import Plugin, ListItem
from collections import namedtuple
from datetime import datetime, timedelta, tzinfo, timezone
from language import get_string
from struct import *
from urllib.parse import urlencode, parse_qsl

import base64
import calendar
import chardet
import ctypes
import glob
import gzip
import io
import json
import os, os.path
import platform
import random
import re
import requests
import shutil
import sqlite3
import stat
import subprocess
import sys
import threading
import time
import xbmcvfs

REC_ENABLE = 1
CREATE_NFO = 1
EPGDB      = xbmcvfs.translatePath('special://database/Epg13.db')
CHANNELDB  = xbmcvfs.translatePath('special://database/TV38.db')
UTC_ADJUST = timedelta(hours=0)
NFO_SUFFIX = '.nfo'
REC_SUFFIX = '.rec'

if platform.system() == 'Windows':
    UTC_ADJUST = UTC_ADJUST + timedelta(hours=1)

try:
    from urllib.parse import quote, quote_plus, unquote_plus
    from html import unescape as html_unescape
    from io import StringIO
    class HTMLParser:
        def unescape(self, string):
            return html_unescape(string)
except ImportError:
    from urllib import quote, quote_plus, unquote_plus
    from HTMLParser import HTMLParser
    from StringIO import StringIO

import uuid
from kodi_six import xbmc, xbmcaddon, xbmcvfs, xbmcgui, xbmcplugin
from kodi_six.utils import encode_decode

def addon_id():
    return xbmcaddon.Addon().getAddonInfo('id')


def log(v, type=xbmc.LOGERROR):
    xbmc.log('[EPGRECORDER]: '+repr(v), type)

plugin = Plugin()
big_list_view = True

@encode_decode
def plugin_url_for(plugin, *args, **kwargs):
    return plugin.url_for(*args, **kwargs)

if plugin.get_setting('multiline', str) == "true":
    CR = "[CR]"
else:
    CR = ""


def get_icon_path(icon_name):
    return "special://home/addons/%s/resources/img/%s.png" % (addon_id(), icon_name)


def remove_formatting(label):
    label = re.sub(r"\[/?[BI]\]", '', label, flags=re.I)
    label = re.sub(r"\[/?COLOR.*?\]", '', label, flags=re.I)
    return label


def escape( str ):
    str = str.replace("&", "&amp;")
    str = str.replace("<", "&lt;")
    str = str.replace(">", "&gt;")
    str = str.replace("\"", "&quot;")
    return str


def unescape( str ):
    str = str.replace("&lt;", "<")
    str = str.replace("&gt;", ">")
    str = str.replace("&quot;", "\"")
    str = str.replace("&amp;", "&")
    return str


def delete(path):
    dirs, files = xbmcvfs.listdir(path)
    for file in files:
        xbmcvfs.delete(path+file)
    for dir in dirs:
        delete(path + dir + '/')
    xbmcvfs.rmdir(path)

def rmdirs(path):
    path = xbmcvfs.translatePath(path)
    dirs, files = xbmcvfs.listdir(path)
    for dir in dirs:
        rmdirs(os.path.join(path,dir))
    xbmcvfs.rmdir(path)


def find(path):
    path = xbmcvfs.translatePath(path)
    all_dirs = []
    all_files = []
    dirs, files = xbmcvfs.listdir(path)
    for file in files:
        file_path = os.path.join(path,file)
        all_files.append(file_path)
    for dir in dirs:
        dir_path = os.path.join(path,dir)
        all_dirs.append(dir_path)
        new_dirs, new_files = find(os.path.join(path, dir))
        for new_dir in new_dirs:
            new_dir_path = os.path.join(path,dir,new_dir)
            all_dirs.append(new_dir_path)
        for new_file in new_files:
            new_file = os.path.join(path,dir,new_file)
            all_files.append(new_file)
    return all_dirs, all_files

def check_has_db_filled_show_error_message_ifn(db_cursor):
    table_found = db_cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='streams'").fetchone()
    if not table_found:
        xbmcgui.Dialog().notification("IPTV Recorder", get_string("Database not found"))
        return False
    return True

@plugin.route('/play_channel/<channelname>')
def play_channel(channelname):
    log(("play_channel called:", channelname))
    conn = sqlite3.connect(xbmcvfs.translatePath('%sxmltv.db' % plugin.addon.getAddonInfo('profile')))
    c = conn.cursor()
    if not check_has_db_filled_show_error_message_ifn(c):
        return

    channel = c.execute("SELECT url FROM streams WHERE name=?", (channelname, )).fetchone()

    if not channel:
        return
    url = channel[0]
    #plugin.set_resolved_url(url)
    xbmc.Player().play(url)


@plugin.route('/play_channel_external/<channelname>')
def play_channel_external(channelname):
    conn = sqlite3.connect(xbmcvfs.translatePath('%sxmltv.db' % plugin.addon.getAddonInfo('profile')))
    c = conn.cursor()
    if not check_has_db_filled_show_error_message_ifn(c):
        return

    channel = c.execute("SELECT url FROM streams WHERE name=?", (channelname, )).fetchone()
    if not channel:
        return
    url = channel[0]

    if url:
        cmd = [plugin.get_setting('external.player', str)]

        args = plugin.get_setting('external.player.args', str)
        if args:
            cmd.append(args)

        cmd.append(url)

        #TODO shell?
        subprocess.Popen(cmd,shell=windows())


@plugin.route('/play_external/<path>')
def play_external(path):
    cmd = [plugin.get_setting('external.player', str)]

    args = plugin.get_setting('external.player.args', str)
    if args:
        cmd.append(args)

    cmd.append(xbmcvfs.translatePath(path))

    subprocess.Popen(cmd,shell=windows())


def xml2local(xml):
    #TODO combine
    return utc2local(xml2utc(xml))


def utc2local(utc):
    timestamp = calendar.timegm(utc.timetuple())
    local = datetime.fromtimestamp(timestamp)
    return local.replace(microsecond=utc.microsecond)

def utc2utc(utc):
    timestamp = calendar.timegm(utc.timetuple())
    local = datetime.fromtimestamp(timestamp)
    return local
    
def str2dt(string_date):
    format ='%Y-%m-%d %H:%M:%S'
    try:
        res = datetime.strptime(string_date, format)
    except TypeError:
        res = datetime(*(time.strptime(string_date, format)[0:6]))
    return utc2local(res)

def total_seconds(td):
    return (td.microseconds + (td.seconds + td.days * 24 * 3600) * 10**6) / 10**6


def windows():
    if os.name == 'nt':
        return True
    else:
        return False


def android_get_current_appid():
    with open("/proc/%d/cmdline" % os.getpid()) as fp:
        return fp.read().rstrip("\0")


@plugin.route('/delete_ffmpeg')
def delete_ffmpeg():
    if xbmc.getCondVisibility('system.platform.android'):
        ffmpeg_dst = '/data/data/%s/ffmpeg' % android_get_current_appid()
        xbmcvfs.delete(ffmpeg_dst)


def ffmpeg_location():
    ffmpeg_src = xbmcvfs.translatePath(plugin.get_setting('ffmpeg', str))

    if xbmc.getCondVisibility('system.platform.android'):
        ffmpeg_dst = '/data/data/%s/ffmpeg' % android_get_current_appid()

        if (plugin.get_setting('ffmpeg', str) != plugin.get_setting('ffmpeg.last', str)) or (not xbmcvfs.exists(ffmpeg_dst) and ffmpeg_src != ffmpeg_dst):
            xbmcvfs.copy(ffmpeg_src, ffmpeg_dst)
            plugin.set_setting('ffmpeg.last',plugin.get_setting('ffmpeg', str))

        ffmpeg = ffmpeg_dst
    else:
        ffmpeg = ffmpeg_src

    if ffmpeg:
        try:
            st = os.stat(ffmpeg)
            if not (st.st_mode & stat.S_IXUSR):
                try:
                    os.chmod(ffmpeg, st.st_mode | stat.S_IXUSR)
                except:
                    pass
        except:
            pass
    if xbmcvfs.exists(ffmpeg):
        return ffmpeg
    else:
        xbmcgui.Dialog().notification("IPTV Recorder", get_string("ffmpeg exe not found!"))

@plugin.route('/record_from_ffplayer/<chname>/<start>/<length>')
def record_from_ffplayer(chname, start, length):
    title = xbmc.getInfoLabel('VideoPlayer.Title')
    log (('record from ffplayer', chname, start, length, title, UTC_ADJUST))
    # log(("url:", xbmc.getInfoLabel('Player.Filenameandpath'),
    #      "title:", xbmc.getInfoLabel('VideoPlayer.Title'),
    #      "cast:", xbmc.getInfoLabel('VideoPlayer.Cast'),
    #      "params:", xbmc.getInfoLabel('VideoPlayer.OriginalTitle'),
    #      "genre:", xbmc.getInfoLabel('VideoPlayer.Genre'),
    #      "time:", xbmc.getInfoLabel('VideoPlayer.Time'),
    #      "duration", xbmc.getInfoLabel('VideoPlayer.Duration'),
    #      "desc:", xbmc.getInfoLabel('VideoPlayer.Plot'),
    # ))

    conn = sqlite3.connect(xbmcvfs.translatePath('%sxmltv.db' % plugin.addon.getAddonInfo('profile')))
    cursor = conn.cursor()
    if not check_has_db_filled_show_error_message_ifn(cursor):
        return

    url = cursor.execute("SELECT url FROM streams WHERE name=?", (chname,)).fetchone()
    url = url[0]
    conn.commit()
    conn.close()
    record_by_url(chname, url, title, start, length)

@plugin.route('/record_from_player/<chname>')
def record_from_player(chname):
    title = xbmc.getInfoLabel('VideoPlayer.Title')
    log(('record from player', chname, title))

    #url = xbmc.Player().getPlayingFile()
    # log(("url:", url,
    #      "chname:", xbmc.getInfoLabel('VideoPlayer.ChannelName'),
    #      "title:", xbmc.getInfoLabel('VideoPlayer.Title'),
    #      "cast:", xbmc.getInfoLabel('VideoPlayer.Cast'),
    #      "params:", xbmc.getInfoLabel('VideoPlayer.OriginalTitle'),
    #      "genre:", xbmc.getInfoLabel('VideoPlayer.Genre'),
    #      "time:", xbmc.getInfoLabel('VideoPlayer.Time'),
    #      "duration", xbmc.getInfoLabel('Player.Duration'),
    #      "position", xbmc.getInfoLabel('VideoPlayer.EndTime'),
    #      "desc:", xbmc.getInfoLabel('VideoPlayer.Plot')
    # ))
    
    conn = sqlite3.connect(xbmcvfs.translatePath('%sxmltv.db' % plugin.addon.getAddonInfo('profile')))
    cursor = conn.cursor()
    if not check_has_db_filled_show_error_message_ifn(cursor):
        return

    url = cursor.execute("SELECT url FROM streams WHERE name=?", (chname,)).fetchone()
    url = url[0]
    conn.commit()
    conn.close()

    conn = sqlite3.connect(EPGDB, detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    c = conn.cursor()

    idEpg = c.execute('SELECT idEpg FROM epg WHERE sName=?',(chname,)).fetchone()
    start, stop = c.execute('SELECT iStartTime, iEndTime FROM epgtags WHERE sTitle=? AND idEpg=? AND iEndTime<?',(title,idEpg[0],int(datetime.now().timestamp()))).fetchone()

    conn.commit()
    conn.close()
    start  = datetime.utcfromtimestamp(start)
    stop   = datetime.utcfromtimestamp(stop)
    my_start = start - UTC_ADJUST
    my_start = str(my_start.replace(tzinfo=timezone.utc).timestamp())
    my_stop = stop - UTC_ADJUST
    my_stop = str(my_stop.replace(tzinfo=timezone.utc).timestamp())
    length = str(total_seconds(stop - start))

    record_by_url(chname, url, title, my_start, length)
    
@plugin.route('/record_epg/<chname>/<tv_number>/<title>/<start>/<stop>')
def record_epg(chname, tv_number, title, start, stop):
    conn = sqlite3.connect(xbmcvfs.translatePath('%sxmltv.db' % plugin.addon.getAddonInfo('profile')))
    cursor = conn.cursor()
    if not check_has_db_filled_show_error_message_ifn(cursor):
        return

    #log((start, stop))

    # https://bugs.python.org/issue27400
    url = cursor.execute("SELECT url FROM streams WHERE name=?", (chname,)).fetchone()

    my_start = str2date(start) - timedelta(hours=SUMMERTIME)
    my_stop = str2date(stop) - timedelta(hours=SUMMERTIME)

    length = str(total_seconds(my_stop - my_start))
    my_start = str(datetime2timestamp(my_start))
    my_stop = str(datetime2timestamp(my_stop))

    #log(("cal recorder with:", chname, tv_number, url[0], title, my_start, length))
    record_by_url(chname, url[0], title, my_start, length)

def add2recently_played(**prog):
    log(('adding prog',prog))
    MAX_RECENTLY_PLAYED = 10
    db = plugin.get_storage('recently_played')
    if db.get('rp_list') == None:
        db['rp_list'] = [prog]
    else :
        if len(db['rp_list']) >= MAX_RECENTLY_PLAYED:
            #TODO: promote program if it is already in the list
            #promote_program
            #log('poping from rp_list')
            db['rp_list'].pop()
        db['rp_list'].insert(0, prog)
    
    return

@plugin.route('/recently_viewed')
def recently_viewed():
    db = plugin.get_storage('recently_played')
    #now = str(int(datetime2timestamp(datetime.now())))
    if db.get('rp_list') == None:
        return
    
    #log('rp_list length is %s' % len(db['rp_list']))
    if len(db['rp_list']) > 0:
        items = []
        for e in db['rp_list']:
            log(e)
            dictitem = {
                'label': e['title'],
                'path': plugin_url_for(plugin, play_by_url, chname=e['chname'], url=e['url'],
                                       title=e['title'], my_start=e['my_start'], my_stop=e['my_stop'],
                                       length=e['length'], plot=e['plot'], base_url=e['base_url'],
                                       picon=e['picon'], thumbnail=e['thumbnail'], add2recent=False),
                #'path': e['url']+now,
                #'thumbnail': thumbnail,
                'info_type': 'video',
                'info':{"title": e['title'], "plot": e['plot'] ,
                        "originaltitle": e['chname'] + '/' + e['my_start'] + '/' + e['length'], #passed to skin for recording
                }, 
                'is_playable' : True,
                #'context_menu': context_items,
            }
            listitem = ListItem().from_dict(**dictitem)
            listitem.set_property('inputstream', 'inputstream.ffmpegdirect')
            listitem.set_property('inputstream.ffmpegdirect.catchup_buffer_start_time', e['my_start'])
            listitem.set_property('inputstream.ffmpegdirect.catchup_buffer_end_time', e['my_stop'])
            listitem.set_property('inputstream.ffmpegdirect.catchup_buffer_offset', "180") # 3 min offset
            listitem.set_property('inputstream.ffmpegdirect.catchup_granularity', str(1))
            listitem.set_property('inputstream.ffmpegdirect.catchup_terminates', 'true')
            listitem.set_property('inputstream.ffmpegdirect.catchup_url_format_string', e['base_url']+'?utc={utc}&lutc={lutc}')
            listitem.set_property('inputstream.ffmpegdirect.default_url', e['base_url'])
            listitem.set_property('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            listitem.set_property('inputstream.ffmpegdirect.manifest_type', 'hls')
            listitem.set_property('inputstream.ffmpegdirect.playback_as_live', 'false')
            listitem.set_property('inputstream.ffmpegdirect.stream_mode', 'catchup')
            listitem.set_property('inputstream.ffmpegdirect.timezone_shift', str(0))
            listitem.set_property('thumbnail', e['thumbnail'])
            listitem._listitem.setArt({"icon": e['picon'], "landscape": e['picon'], "clearart": e['thumbnail'],
                                       "clearlogo": e['picon'], "thumb": e['picon'], "poster": e['thumbnail'],
                                       "banner": e['thumbnail'], "fanart":e['thumbnail']})
            items.append(listitem)
        return items
        
    
def get_utc_from_string(date_string):
    utcnow = datetime.utcnow()
    ts = time.time()
    utc_offset = total_seconds(datetime.fromtimestamp(ts) - datetime.utcfromtimestamp(ts))

    r = re.search(r'(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):\d{2}', date_string)
    if r:
        year, month, day, hour, minute = r.group(1), r.group(2), r.group(3), r.group(4), r.group(5)
        return utcnow.replace(day=int(day), month=int(month), year=int(year), hour=int(hour), minute=int(minute),
                              second=0, microsecond=0) - timedelta(seconds=utc_offset)
def write_in_file(file, string):
    file.write(bytearray(string.encode('utf8')))

@plugin.route('/convert/<path>')
def convert(path):
    input = xbmcvfs.File(path,'rb')
    output = xbmcvfs.File(path.replace('.ts','.mp4'),'wb')
    error = open(xbmcvfs.translatePath("special://profile/addon_data/plugin.video.epg.recorder/errors.txt"), "w", encoding='utf-8')

    cmd = [ffmpeg_location(),"-fflags","+genpts","-y","-i","-","-vcodec","copy","-acodec","copy","-f", "mpegts", "-"]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=error, shell=windows())
    t = threading.Thread(target=read_thread,args=[p,output])
    t.start()

    while True:
        data_bytes = bytes(input.readBytes(100000))
        if not data_bytes:
            break
        p.stdin.write(bytearray(data_bytes))
    p.stdin.close()
    error.close()



def read_thread(p,output):
    while True:
        data = p.stdout.read(100000)
        if not len(data):
            break
        output.write(data)
    output.close()


def sane_name(name):
    if not name:
        return
    if windows() or (plugin.get_setting('filename.urlencode', str) == 'true'):
        name = quote(name.encode('utf-8'))
        name = name.replace("%20",' ')
        name = name.replace('/',"%2F")
    else:
        _quote = {'"': '%22', '|': '%7C', '*': '%2A', '/': '%2F', '<': '%3C', ':': '%3A', '\\': '%5C', '?': '%3F', '>': '%3E'}
        for char in _quote:
            name = name.replace(char, _quote[char])
    return name


def refresh():
    containerAddonName = xbmc.getInfoLabel('Container.PluginName')
    AddonName = xbmcaddon.Addon().getAddonInfo('id')
    if (containerAddonName == AddonName) and (plugin.get_setting('refresh', str) == 'true') :
        xbmc.executebuiltin('Container.Refresh')


def datetime2timestamp(dt):
    epoch=datetime.fromtimestamp(0.0)
    td = dt - epoch
    return (td.microseconds + (td.seconds + td.days * 86400) * 10**6) / 10**6


def timestamp2datetime(ts):
    return datetime.fromtimestamp(ts)


def time2str(t):
    return "%02d:%02d" % (t.hour,t.minute)


def str2time(s):
    return datetime.time(hour=int(s[0:1],minute=int(s[3:4])))


def day(timestamp):
    if timestamp:
        today = datetime.today()
        tomorrow = today + timedelta(days=1)
        yesterday = today - timedelta(days=1)
        if today.date() == timestamp.date():
            return get_string('Today')
        elif tomorrow.date() == timestamp.date():
            return get_string('Tomorrow')
        elif yesterday.date() == timestamp.date():
            return get_string('Yesterday')
        else:
            return get_string(timestamp.strftime("%A"))


@plugin.route('/delete_search_title/<title>')
def delete_search_title(title):
    searches = plugin.get_storage('search_title')
    if title in searches:
        del searches[title]
    refresh()


@plugin.route('/search_title_dialog')
def search_title_dialog():
    searches = plugin.get_storage('search_title')

    items = []
    items.append({
        "label": "New",
        "path": plugin_url_for(plugin, 'search_title_input', title='title'),
        "thumbnail": get_icon_path('search'),
    })

    for search in searches:
        context_items = []
        #log(search)
        context_items.append((get_string("Delete Search"), 'RunPlugin(%s)' % (plugin_url_for(plugin, delete_search_title, title=search))))
        items.append({
            "label": search,
            "path": plugin_url_for(plugin, 'search_title', title=search),
            "thumbnail": get_icon_path('search'),
            'context_menu': context_items,
            })
    return items


@plugin.route('/search_title_input/<title>')
def search_title_input(title):
    searches = plugin.get_storage('search_title')
    if title == "title":
        title = ""
    d = xbmcgui.Dialog()
    what = d.input(get_string("Search Title"), title)
    #log(what)
    if not what:
        return
    searches[what] = ''
    return search_title(what)


@plugin.route('/search_title/<title>')
def search_title(title):
    if plugin.get_setting('add.context.searches', str) == 'true':
        searches = plugin.get_storage('search_title')
        searches[title] = ''

    conn = sqlite3.connect(xbmcvfs.translatePath('%sxmltv.db' % plugin.addon.getAddonInfo('profile')), detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    cursor = conn.cursor()
    if not check_has_db_filled_show_error_message_ifn(cursor):
        return

    programmes = cursor.execute(
    'SELECT uid, channelid , title , sub_title , start AS "start [TIMESTAMP]", stop AS "stop [TIMESTAMP]", date , description , episode, categories FROM programmes WHERE title LIKE ? ORDER BY start, stop, channelid',
    ("%"+title+"%", )).fetchall()

    conn.commit()
    conn.close()

    return listing(programmes, scroll=True)


@plugin.route('/delete_search_plot/<plot>')
def delete_search_plot(plot):
    searches = plugin.get_storage('search_plot')
    if plot in searches:
        del searches[plot]
    refresh()


@plugin.route('/search_plot_dialog')
def search_plot_dialog():
    searches = plugin.get_storage('search_plot')

    items = []
    items.append({
        "label": get_string("New"),
        "path": plugin_url_for(plugin, 'search_plot_input', plot='plot'),
        "thumbnail": get_icon_path('search'),
    })

    for search in searches:
        context_items = []
        context_items.append(("Delete Search" , 'RunPlugin(%s)' % (plugin_url_for(plugin, delete_search_plot, plot=search))))
        items.append({
            "label": search,
            "path": plugin_url_for(plugin, 'search_plot', plot=search),
            "thumbnail": get_icon_path('search'),
            'context_menu': context_items,
            })
    return items


@plugin.route('/search_plot_input/<plot>')
def search_plot_input(plot):
    searches = plugin.get_storage('search_plot')
    if plot == "plot":
        plot = ""
    d = xbmcgui.Dialog()
    what = d.input(get_string("Search Plot"), plot)
    if not what:
        return
    searches[what] = ''
    return search_plot(what)


@plugin.route('/search_plot/<plot>')
def search_plot(plot):
    #TODO combine with search_title() and group()
    conn = sqlite3.connect(xbmcvfs.translatePath('%sxmltv.db' % plugin.addon.getAddonInfo('profile')), detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    cursor = conn.cursor()
    if not check_has_db_filled_show_error_message_ifn(cursor):
        return

    programmes = cursor.execute(
    'SELECT uid, channelid , title , sub_title , start AS "start [TIMESTAMP]", stop AS "stop [TIMESTAMP]", date , description , episode, categories FROM programmes WHERE description LIKE ? ORDER BY start, stop, channelid',
    ("%"+plot+"%", )).fetchall()

    conn.commit()
    conn.close()

    return listing(programmes, scroll=True)


@plugin.route('/delete_search_categories/<categories>')
def delete_search_categories(categories):
    searches = plugin.get_storage('search_categories')
    if categories in searches:
        del searches[categories]
    refresh()


@plugin.route('/search_categories_dialog')
def search_categories_dialog():
    searches = plugin.get_storage('search_categories')

    items = []
    items.append({
        "label": get_string("New"),
        "path": plugin_url_for(plugin, 'search_categories_input', categories='categories'),
        "thumbnail": get_icon_path('search'),
    })

    for search in searches:
        context_items = []
        context_items.append(("Delete Search" , 'RunPlugin(%s)' % (plugin_url_for(plugin, delete_search_categories, categories=search))))
        items.append({
            "label": search,
            "path": plugin_url_for(plugin, 'search_categories', categories=search),
            "thumbnail": get_icon_path('search'),
            'context_menu': context_items,
            })
    return items


@plugin.route('/search_categories_input/<categories>')
def search_categories_input(categories):
    conn = sqlite3.connect(xbmcvfs.translatePath('%sxmltv.db' % plugin.addon.getAddonInfo('profile')), detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    cursor = conn.cursor()
    if not check_has_db_filled_show_error_message_ifn(cursor):
        return

    programmes = cursor.execute('SELECT DISTINCT categories FROM programmes').fetchall()

    cats = set()
    for programme in programmes:
        programme_categories = programme[0]
        cats.add(programme_categories)
        programme_categories = programme_categories.split(', ')
        for category in programme_categories:
            if category:
                cats.add(category)
    cats = sorted(list(cats))

    searches = plugin.get_storage('search_categories')
    if categories == "categories":
        categories = ""
    d = xbmcgui.Dialog()
    what = d.select(get_string("Search categories"), cats)
    if not what:
        return
    what = cats[what]
    what = what.strip()
    searches[what] = ''
    return search_categories(what)


@plugin.route('/search_categories/<categories>')
def search_categories(categories):
    if plugin.get_setting('add.context.searches', str) == 'true':
        searches = plugin.get_storage('search_categories')
        searches[categories] = ''

    #TODO combine with search_title() and group()
    conn = sqlite3.connect(xbmcvfs.translatePath('%sxmltv.db' % plugin.addon.getAddonInfo('profile')), detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    cursor = conn.cursor()
    if not check_has_db_filled_show_error_message_ifn(cursor):
        return

    programmes = cursor.execute(
    'SELECT uid, channelid , title , sub_title , start AS "start [TIMESTAMP]", stop AS "stop [TIMESTAMP]", date , description , episode, categories FROM programmes WHERE categories LIKE ? ORDER BY start, stop, channelid',
    ("%"+categories+"%", )).fetchall()

    conn.commit()
    conn.close()

    return listing(programmes, scroll=True)


@plugin.route('/channel/<channelid>/<channelname>')
def channel(channelid,channelname):
    conn = sqlite3.connect(xbmcvfs.translatePath('%sxmltv.db' % plugin.addon.getAddonInfo('profile')), detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    cursor = conn.cursor()
    if not check_has_db_filled_show_error_message_ifn(cursor):
        return

    thumbnail = cursor.execute("SELECT tvg_logo FROM streams WHERE tvg_id=?", (channelid, )).fetchone()
    if not thumbnail:
        thumbnail = cursor.execute("SELECT icon FROM channels WHERE id=?", (channelid, )).fetchone()
    if thumbnail:
        thumbnail = thumbnail[0]
    else:
        thumbnail = ''

    programmes = cursor.execute(
    'SELECT uid, channelid , title , sub_title , start AS "start [TIMESTAMP]", stop AS "stop [TIMESTAMP]", date , description , episode, categories FROM programmes WHERE channelid=?', (channelid, )).fetchall()

    conn.commit()
    conn.close()

    if plugin.get_setting('add.favourite.channel', str) == 'true':
        add_favourite_channel(channelname, channelid, thumbnail)

    return listing(programmes, scroll=True, channelname=channelname)


@plugin.route('/tv_show/<title>')
def tv_show(title):
    conn = sqlite3.connect(xbmcvfs.translatePath('%sxmltv.db' % plugin.addon.getAddonInfo('profile')), detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    cursor = conn.cursor()
    if not check_has_db_filled_show_error_message_ifn(cursor):
        return

    programmes = cursor.execute(
    'SELECT uid, channelid , title , sub_title , start AS "start [TIMESTAMP]", stop AS "stop [TIMESTAMP]", date , description , episode, categories FROM programmes WHERE title=? ORDER BY start, channelid, title', (title, )).fetchall()

    conn.commit()
    conn.close()

    return listing(programmes, scroll=True)


@plugin.route('/other/<title>')
def other(title):
    conn = sqlite3.connect(xbmcvfs.translatePath('%sxmltv.db' % plugin.addon.getAddonInfo('profile')), detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    cursor = conn.cursor()
    if not check_has_db_filled_show_error_message_ifn(cursor):
        return

    programmes = cursor.execute(
    'SELECT uid, channelid , title , sub_title , start AS "start [TIMESTAMP]", stop AS "stop [TIMESTAMP]", date , description , episode, categories FROM programmes WHERE episode IS null AND title=? ORDER BY start, channelid, title', (title, )).fetchall()

    conn.commit()
    conn.close()

    return listing(programmes, scroll=True)


@plugin.route('/category/<title>')
def category(title):
    #programmes = cursor.execute(
    #    'SELECT uid, channelid , title , sub_title , start AS "start [TIMESTAMP]", stop AS "stop [TIMESTAMP]", date , description , episode, categories, icon FROM programmes WHERE categories LIKE ? AND stop<? ORDER BY date DESC, start DESC', ("%"+title+"%", datetime.utcnow())).fetchall()

    conn = sqlite3.connect(EPGDB, detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    c = conn.cursor()

    programmes = c.execute('SELECT idEpg, sTitle, iStartTime, iEndTime, iYear , sPlot , sGenre, sIconPath FROM epgtags WHERE sGenre LIKE ? AND iEndTime<? ORDER BY iYear DESC, iStartTime DESC',("%"+title+"%", int(datetime.now().timestamp()))).fetchall()
    # sTitle should be @ position 1 to uniqify later by title
    # sort by DESC order to corrctly uniqify for latest programm

    conn.commit()
    conn.close()

    return listing_movies(programmes, scroll=True)

@plugin.route('/movie/<title>/<date>')
def movie(title, date):
    conn = sqlite3.connect(xbmcvfs.translatePath('%sxmltv.db' % plugin.addon.getAddonInfo('profile')), detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    cursor = conn.cursor()
    if not check_has_db_filled_show_error_message_ifn(cursor):
        return

    if date != "None":
        programmes = cursor.execute(
        'SELECT uid, channelid , title , sub_title , start AS "start [TIMESTAMP]", stop AS "stop [TIMESTAMP]", date , description , episode, categories FROM programmes WHERE title=? AND date=? ORDER BY start DESC, channelid, title', (title, date)).fetchall()
    else:
        programmes = cursor.execute(
        'SELECT uid, channelid , title , sub_title , start AS "start [TIMESTAMP]", stop AS "stop [TIMESTAMP]", date , description , episode, categories FROM programmes WHERE title=? ORDER BY start DESC, channelid, title', (title, )).fetchall()

    conn.commit()
    conn.close()

    return listing_movies(programmes, scroll=True)

def uniqify_programs(programmes):
    res = []
    skip_list = []
    
    for p in programmes:
        if p[1] in skip_list:
            continue
        else:
            skip_list.append(p[1])
            res.append(p)
            #log("appending " + p[1])
            
    #log(res)
    return res

def listing_movies(programmes, scroll=False, channelname=None):
    
    if channelname:
        channelname = unquote_plus(channelname)

    conn = sqlite3.connect(xbmcvfs.translatePath('%sxmltv.db' % plugin.addon.getAddonInfo('profile')), detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    cursor = conn.cursor()
    if not check_has_db_filled_show_error_message_ifn(cursor):
        return

    streams = cursor.execute("SELECT uid, name, tvg_name, tvg_id, tvg_logo, groups, url FROM streams").fetchall()
    #streams = {x[3]:x for x in streams}
    streams = dict((x[1],x[6]) for x in streams)
    
    channels = cursor.execute("SELECT * FROM channels").fetchall()
    #{'131': (1, '131', 'Первый канал HD', 'http://myott.tv/images/131.png'),...}
    picons = dict((x[2],x[3]) for x in channels)
    items = []

    now = datetime.now()

    programmes = uniqify_programs(programmes)
    
    conn.commit()
    conn.close()

    conn = sqlite3.connect(EPGDB)
    c = conn.cursor()

    for p in programmes:
        idEpg , title , start , stop , date , description , categories, thumbnail = p

        chname = c.execute('SELECT sName FROM epg WHERE idEPG=?',(idEpg,) ).fetchone()
        chname = str(chname[0])
        picon  = picons.get(chname)
        start  = datetime.utcfromtimestamp(start)
        stop   = datetime.utcfromtimestamp(stop)
        url    = streams.get(chname)
        #log(('listing:', chname, title, start, categories, picon, description))

        episode = " "

        color = ""
        stitle = "[COLOR %s]%s[/COLOR][COLOR grey]%s[/COLOR]" % (color, title, episode)


        #label = "%02d:%02d-%02d:%02d [COLOR grey]%s/%s[/COLOR] %s %s %s%s (%s)" % (start.hour, start.minute, stop.hour, stop.minute, start.day,
        #                                                                           start.month, channelname_label, categories_label, CR, stitle, date)

        label = '['+ str(date) +'] ' + stitle + "[COLOR grey](dtl: %s)[/COLOR]" % (get_remaining_time(start).days)

        context_items = []

        #log(UTC_ADJUST)
        my_start = start - UTC_ADJUST
        my_start = str(my_start.replace(tzinfo=timezone.utc).timestamp())
        my_stop = stop - UTC_ADJUST
        my_stop = str(my_stop.replace(tzinfo=timezone.utc).timestamp())
        length = str(total_seconds(stop - start))
        #now = str(int(datetime2timestamp(datetime.now())))
        #path = url + "?utc=" + my_start + "&lutc=" + now
        path = url + "?utc=" + my_start + "&lutc="

        #context_items.append(("[COLOR red]%s[/COLOR]" % "Record Programme",
        #                      'RunPlugin(%s)' % (plugin_url_for(plugin, record_by_url, channelname=chname,
        #                                                        url=url,title=title,start=my_start, length=length))))
        
        dictitem = {
            'label': label,
            'path': plugin_url_for(plugin, play_by_url, chname=chname, url=path, base_url=url, title=title,
                                   my_start=my_start, my_stop=my_stop, length=length, plot=description,
                                   picon=picon, thumbnail=thumbnail, add2recent=True),
            #'path': path+new1,
            'thumbnail': thumbnail,
            'info_type': 'video',
            'info':{"title": title, "plot":description ,
                    "genre":categories, "cast":['Actor1', 'Actor2'],
                    "originaltitle": chname + '/' + my_start + '/' + length, #passed to skin for recording
            }, 
            'is_playable' : True,
            'context_menu': context_items,
        }
        listitem = ListItem().from_dict(**dictitem)
        listitem.set_property('inputstream', 'inputstream.ffmpegdirect')
        listitem.set_property('inputstream.ffmpegdirect.catchup_buffer_start_time', my_start)
        listitem.set_property('inputstream.ffmpegdirect.catchup_buffer_end_time', my_stop)
        listitem.set_property('inputstream.ffmpegdirect.catchup_buffer_offset', "180") # 3 min offset
        listitem.set_property('inputstream.ffmpegdirect.catchup_granularity', str(1))
        listitem.set_property('inputstream.ffmpegdirect.catchup_terminates', 'true')
        listitem.set_property('inputstream.ffmpegdirect.catchup_url_format_string', url+'?utc={utc}&lutc={lutc}')
        listitem.set_property('inputstream.ffmpegdirect.default_url', url)
        listitem.set_property('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        listitem.set_property('inputstream.ffmpegdirect.manifest_type', 'hls')
        listitem.set_property('inputstream.ffmpegdirect.playback_as_live', 'false')
        listitem.set_property('inputstream.ffmpegdirect.stream_mode', 'catchup')
        listitem.set_property('inputstream.ffmpegdirect.timezone_shift', str(0))
        listitem.set_property('thumbnail', thumbnail)
        listitem._listitem.setArt({"icon": picon, "landscape": picon, "clearart": thumbnail,
                                   "clearlogo": picon, "thumb": picon, "poster": thumbnail, "banner": thumbnail, "fanart":thumbnail})
        items.append(listitem)

    conn.commit()
    conn.close()

    return items

@plugin.route('/play_by_url/<chname>/<url>/<base_url>/<title>/<my_start>/<my_stop>/<length>/<picon>/<thumbnail>/<add2recent>/<plot>')
def play_by_url(chname, url, base_url, title, my_start, my_stop, length, picon, thumbnail, add2recent, plot):
    #log(('play_by_url:', chname, url, base_url, title, my_start, my_stop, length, plot))
    log(('play_by_url', add2recent))
    now = str(int(datetime2timestamp(datetime.now())))
    if add2recent=="True":
        add2recently_played(chname=chname, url=url, base_url=base_url, title=title, my_start=my_start,
                            my_stop=my_stop, length=length, plot=plot, picon=picon, thumbnail=thumbnail)
    plugin.set_resolved_url(url+now)

def purify_filename(fname):
    fname = re.sub(r'(?!%s)[^\w\-_\.]', '', fname)
    fname = re.sub('\.+', '.', fname)
    fname = re.sub('^\.+', '', fname)
    return fname

def purify_title(title):
    title = re.sub('Х/ф ', '', title)
    title = re.sub('М/ф ', '', title)
    title = re.sub('"', '', title)
    title = re.sub(':', '', title)
    title = re.sub('/', '_', title)
    title = re.sub(r'\\', '_', title)
    title = re.sub('(\.\s*$)', '', title)
    return title


@plugin.route('/record_by_url/<channelname>/<url>/<title>/<start>/<length>')
def record_by_url(channelname, url, title, start, length):
    #url = url + '?utc=' #+ start + '&lutc=' + str(int(datetime2timestamp(datetime.now())))
    log(("actual recording:", channelname, url, title, start, length))
    kodi_recordings = xbmcvfs.translatePath(plugin.get_setting('recordings', str))
    ffmpeg_recordings = plugin.get_setting('ffmpeg.recordings', str) or kodi_recordings
    ptitle = purify_title(title)
    if REC_ENABLE:
        fname = ffmpeg_recordings + "/" + ptitle + REC_SUFFIX
        if xbmcvfs.exists(fname+'.done'):
            xbmcgui.Dialog().notification("EPG Recorder - Already Recorded", channelname+': '+title, xbmcgui.NOTIFICATION_ERROR, 10000)
        else:
            f = xbmcvfs.File(fname, 'w')
            f.write("$channel = '%s';\n" % channelname)
            f.write("$url     = '%s';\n" % url)
            f.write("$title   = '%s';\n" % ptitle)
            f.write("$start   = '%s';\n" % start)
            f.write("$now     = '%s';\n" % str(datetime2timestamp(datetime.now())))
            f.write("$length  = '%s';\n1\n" % length)
            f.close()
            
            xbmcgui.Dialog().notification("Recoding Started", channelname+': '+title, xbmcgui.NOTIFICATION_INFO, 10000, sound=False)

    if CREATE_NFO:
        # id = 10025

        # xbmc.executebuiltin('ActivateWindow(%d)' % id)
        # xbmc.sleep(100)

        # win = xbmcgui.Window(id)
        # cid = win.getFocusId()
        # if cid:
        #     clist = win.getControl(cid)
        #     if clist:
        #         li = clist.getSelectedItem()
        #         log(li)

        fname = ffmpeg_recordings + "/" + ptitle + NFO_SUFFIX
        f = xbmcvfs.File(fname, 'w')
        f.write('{"ptitle" : %s,\n' % json.dumps(ptitle))
        f.write('"title"   : %s,\n' % json.dumps(title))
        f.write('"pcon"   : %s,\n' % json.dumps(xbmc.getInfoLabel('Player.Icon')))
        f.write('"plot"   : %s}\n' % json.dumps(xbmc.getInfoLabel('VideoPlayer.Plot')))
        f.close()
    return

def get_remaining_time(startime):
    return timedelta(days=7) - (datetime.now() - utc2local(startime))

def focus(i):

    #TODO find way to check this has worked (clist.getSelectedPosition returns -1)
    xbmc.sleep(int(plugin.get_setting('scroll.ms', str) or "0"))
    #TODO deal with hidden ..
    win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    cid = win.getFocusId()
    if cid:
        clist = win.getControl(cid)
        if clist:
            try: clist.selectItem(i)
            except: pass


@plugin.route('/remove_favourite_channel/<channelname>')
def remove_favourite_channel(channelname):
    conn = sqlite3.connect(xbmcvfs.translatePath('%sxmltv.db' % plugin.addon.getAddonInfo('profile')))

    conn.execute("DELETE FROM favourites WHERE channelname=?", (channelname, ))

    conn.commit()
    conn.close()

    refresh()


@plugin.route('/add_favourite_channel/<channelname>/<channelid>/<thumbnail>')
def add_favourite_channel(channelname, channelid, thumbnail):
    conn = sqlite3.connect(xbmcvfs.translatePath('%sxmltv.db' % plugin.addon.getAddonInfo('profile')))

    conn.execute("INSERT OR REPLACE INTO favourites(channelname, channelid, logo) VALUES(?, ?, ?)",
    [channelname, channelid, thumbnail])

    conn.commit()
    conn.close()

    refresh()


@plugin.route('/favourite_channels')
def favourite_channels():
    return group(section="FAVOURITES")



@plugin.route('/group/<channelgroup>')
def group(channelgroup=None,section=None):
    show_now_next = False

    conn = sqlite3.connect(xbmcvfs.translatePath('%sxmltv.db' % plugin.addon.getAddonInfo('profile')), detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    cursor = conn.cursor()
    if not check_has_db_filled_show_error_message_ifn(cursor):
        return

    order_settings = plugin.get_setting('sort.channels.v2', str)
    if order_settings == '1':
        order_channels = " ORDER by name"
        order_favourites = " ORDER by channelname"
        order_stream = " ORDER by name"
    else:
        order_channels = " INNER JOIN streams ON streams.tvg_id = channels.id ORDER BY tv_number";
        order_favourites = " INNER JOIN streams ON streams.tvg_id = favourites.channelid ORDER BY tv_number";
        order_stream = " ORDER by tv_number"

    logos = {}
    channel_logos = {}
    if section == "EPG":
        channels = cursor.execute("SELECT channels.id, channels.name, channels.icon FROM channels" + order_channels).fetchall()
        streams = cursor.execute("SELECT tvg_id, tvg_logo FROM streams").fetchall()
        #logos = {x[0]:x[1] for x in streams}
        logos = dict((x[0],x[1]) for x in streams)

        collection = channels
        show_now_next = plugin.get_setting('show.now.next.all', str) == "true"
    elif section == "FAVOURITES":
        favourite_channels = cursor.execute("SELECT channelname, channelid, logo FROM favourites" + order_favourites).fetchall()
        streams = cursor.execute("SELECT uid, name, tvg_name, tvg_id, tvg_logo, groups, url FROM streams" + order_stream).fetchall()
        collection = favourite_channels
        show_now_next = plugin.get_setting('show.now.next.favourites', str) == "true"
    else:
        channels = cursor.execute("SELECT * FROM channels" + order_channels).fetchall()
        #channel_logos = {x[1]:x[3] for x in channels}
        channel_logos = dict((x[1],x[3]) for x in channels)
        if channelgroup == "All_Channels":
            streams = cursor.execute("SELECT uid, name, tvg_name, tvg_id, tvg_logo, groups, url FROM streams" + order_stream).fetchall()
            show_now_next = plugin.get_setting('show.now.next.all', str) == "true"
        else:
            streams = cursor.execute("SELECT uid, name, tvg_name, tvg_id, tvg_logo, groups, url FROM streams WHERE groups=?" + order_stream, (channelgroup, )).fetchall()
            show_now_next = plugin.get_setting('show.now.next.lists', str) == "true"
        collection = streams

    favourites = cursor.execute("SELECT channelname FROM favourites").fetchall()
    favourites = [x[0] for x in favourites]

    all_streams = cursor.execute("SELECT uid, name, tvg_name, tvg_id, tvg_logo, groups, url FROM streams" + order_stream).fetchall()
    #stream_urls = {x[3]:x[6] for x in all_streams if x}
    stream_urls = dict((x[3],x[6]) for x in all_streams if x)

    items = []

    now = datetime.utcnow()

    if show_now_next:
        now_titles = cursor.execute('SELECT channelid, title, start AS "start [TIMESTAMP]", description, categories FROM programmes WHERE start<? AND stop>?', (now, now)).fetchall()
        #now_titles = {x[0]:(x[1],x[2],x[3],x[4]) for x in now_titles}
        now_titles = dict((x[0],(x[1],x[2],x[3],x[4])) for x in now_titles)
        #TODO limit to one per channelid
        next_titles = cursor.execute('SELECT channelid, title, start AS "start [TIMESTAMP]", categories FROM programmes WHERE start>? ORDER BY start DESC', (now,)).fetchall()
        #next_titles = {x[0]:(x[1],x[2],x[3]) for x in next_titles}
        next_titles = dict((x[0],(x[1],x[2],x[3])) for x in next_titles)

    for stream_channel in collection:
        #log(stream_channel)

        url = ""
        if section == "EPG":
            id, name, icon = stream_channel
            channelname = name
            channelid = id
            url = stream_urls.get(channelid)
            thumbnail = logos.get(channelid) or icon or get_icon_path('tv')
            logo = icon
        elif section == "FAVOURITES":
            channelname, channelid, thumbnail = stream_channel
            url = stream_urls.get(channelid)
            logo = thumbnail
            thumbnail = logo or get_icon_path('tv')
        else:
            uid, name, tvg_name, tvg_id, tvg_logo, groups, url = stream_channel
            channelname = name or tvg_name
            channelid = tvg_id
            #if not channelid:
                #continue
            thumbnail = tvg_logo or logos.get(channelid) or channel_logos.get(channelid) or get_icon_path('tv')
            logo = tvg_logo

        description = ""
        categories = ""

        if show_now_next:

            if channelid in now_titles:
                title = now_titles[channelid][0]
                local_start = utc2local(now_titles[channelid][1])
                description = now_titles[channelid][2]
                if plugin.get_setting('show.categories', str) == 'true':
                    categories = "[COLOR grey]%s[/COLOR]" % now_titles[channelid][3]
                else:
                    categories = ""
                now_title = "[COLOR yellow]%02d:%02d %s[/COLOR] %s" % (local_start.hour, local_start.minute, title, categories)
            else:
                now_title = ""

            if channelid in next_titles:
                title = next_titles[channelid][0]
                local_start = utc2local(next_titles[channelid][1])
                if plugin.get_setting('show.categories', str) == 'true':
                    next_categories = "[COLOR grey]%s[/COLOR]" % next_titles[channelid][2]
                else:
                    next_categories = ""
                next_title =  "[COLOR blue]%02d:%02d %s[/COLOR] %s" % (local_start.hour, local_start.minute, title, next_categories)
            else:
                next_title = ""

            if plugin.get_setting('show.now.next.hide.empty', str) == "true" and not now_title and not next_title:
                continue

            if (plugin.get_setting('hide.channel.name', str) == "true") and logo:
                label = "%s %s%s" % (now_title, CR, next_title)
            else:
                label = u"%s %s %s%s" % (channelname, now_title, CR, next_title)


        else:
            label = channelname

        context_items = []

        if channelid:
            channelid_encoded = channelid
        else:
            channelid_encoded = "NO_CHANNEL_ID"

        if url:
            context_items.append((get_string("Add One Time Rule"), 'RunPlugin(%s)' % (plugin_url_for(plugin, record_one_time, channelname=channelname))))
            context_items.append((get_string("Add Daily Time Rule"), 'RunPlugin(%s)' % (plugin_url_for(plugin, record_daily_time, channelname=channelname))))
            context_items.append((get_string("Add Weekly Time Rule"), 'RunPlugin(%s)' % (plugin_url_for(plugin, record_weekly_time, channelname=channelname))))
            context_items.append((get_string("Record and Play"), 'RunPlugin(%s)' % (plugin_url_for(plugin, record_and_play, channelid=channelid_encoded, channelname=channelname))))
            if channelid:
                context_items.append((get_string("Add Title Search Rule"), 'RunPlugin(%s)' % (plugin_url_for(plugin, record_always_search, channelid=channelid_encoded, channelname=channelname))))
                context_items.append((get_string("Add Plot Search Rule"), 'RunPlugin(%s)' % (plugin_url_for(plugin, record_always_search_plot, channelid=channelid_encoded, channelname=channelname))))
            context_items.append((get_string("Play Channel"), 'RunPlugin(%s)' % (plugin_url_for(plugin, play_channel, channelname=channelname))))
            if plugin.get_setting('external.player', str):
                context_items.append((get_string("Play Channel External"), 'RunPlugin(%s)' % (plugin_url_for(plugin, play_channel_external, channelname=channelname))))

        if channelname not in favourites and channelid:
            context_items.append((get_string("Add Favourite Channel"), 'RunPlugin(%s)' % (plugin_url_for(plugin, add_favourite_channel, channelname=channelname, channelid=channelid_encoded, thumbnail=thumbnail))))
        else:
            context_items.append((get_string("Remove Favourite Channel"), 'RunPlugin(%s)' % (plugin_url_for(plugin, remove_favourite_channel, channelname=channelname))))

        if url and channelid:
            path = plugin_url_for(plugin, channel, channelid=channelid_encoded, channelname=channelname)
        else:
            path = sys.argv[0]

        items.append({
            'label': label,
            'path': path,
            'context_menu': context_items,
            'thumbnail': thumbnail,
            'info':{"plot":description, "genre":categories}
        })

    return items


@plugin.route('/categories')
def categories():

    status = plugin.get_storage('status', TTL=1440) # rescan channels daily
    if 'running' not in status.keys():
        status['running'] = True
        xmltv()

    items = []

    conn = sqlite3.connect(EPGDB)
    c = conn.cursor()

    titles = c.execute("SELECT DISTINCT sGenre FROM epgtags ORDER BY sGenre").fetchall()

    cats = set()
    for title in titles:
        programme_categories = title[0]
        cats.add(programme_categories)
        programme_categories = programme_categories.split(', ')
        for cat in programme_categories:
            if cat:
                cats.add(cat)
    cats = sorted(list(cats))

    for cat in cats:
        if not cat or ',' in cat:
            continue
        label = cat
        title = cat

        items.append({
            'label': label,
            'path': plugin_url_for(plugin, category, title=title),
            'thumbnail': get_icon_path('folder'),
        })
    conn.commit()
    conn.close()

    return items


@plugin.route('/delete_recording/<label>/<path>')
def delete_recording(label, path):
    if not (xbmcgui.Dialog().yesno("IPTV Recorder", "[COLOR red]" + get_string("Delete Recording?") + "[/COLOR]\n" + label)):
        return
    if not xbmcvfs.delete(path):
        return
    length = int(len('.' + plugin.get_setting('ffmpeg.ext', str)))
    xbmcvfs.delete(path[:-length]+NFO_SUFFIX)
    xbmcvfs.delete(path[:-length]+REC_SUFFIX+'.done')
    refresh()


@plugin.route('/delete_all_recordings')
def delete_all_recordings():
    result = xbmcgui.Dialog().yesno("IPTV Recorder", "[COLOR red]" + get_string("Delete All Recordings?") + "[/COLOR]")
    if not result:
        return

    dir = plugin.get_setting('recordings', str)
    dirs, files = find(dir)
    for file in sorted(files):
        if file.endswith('.' + plugin.get_setting('ffmpeg.ext', str)):
            success = xbmcvfs.delete(file)
            if success:
                length = int(len('.' + plugin.get_setting('ffmpeg.ext', str)))
                json_file = file[:-length]+'.json'
                xbmcvfs.delete(json_file)

    rmdirs(dir)
    refresh()


def find_files(root):
    dirs, files = xbmcvfs.listdir(root)
    found_files = []
    for dir in dirs:
        path = os.path.join(xbmcvfs.translatePath(root), dir)
        found_files = found_files + find_files(path)
    file_list = []
    for file in files:
        if file.endswith('.' + plugin.get_setting('ffmpeg.ext', str)):
            file = os.path.join(xbmcvfs.translatePath(root), file)
            file_list.append(file)
    return found_files + file_list


@plugin.route('/recordings')
def recordings():
    dir = plugin.get_setting('recordings', str)
    found_files = find_files(dir)

    items = []
    starts = []

    conn = sqlite3.connect(xbmcvfs.translatePath('%sxmltv.db' % plugin.addon.getAddonInfo('profile')), detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    cursor = conn.cursor()

    for path in found_files:
        json_file = path[:-3]+NFO_SUFFIX
        if xbmcvfs.exists(json_file):
            info = json.loads(xbmcvfs.File(json_file).read())
            title = info.get('title')
            pcon  = info.get('pcon')
            plot  = info.get('plot')
            label = title
        else:
            label = os.path.splitext(os.path.basename(path))[0]
            plot = ""
            pcon = "None"
            label = unquote_plus(label)

        context_items = []

        context_items.append((get_string("Delete Recording"), 'RunPlugin(%s)' % (plugin_url_for(plugin, delete_recording, label=label, path=path))))
        #context_items.append((get_string("Delete All Recordings"), 'RunPlugin(%s)' % (plugin_url_for(plugin, delete_all_recordings))))
        if plugin.get_setting('external.player', str):
            context_items.append((get_string("External Player"), 'RunPlugin(%s)' % (plugin_url_for(plugin, play_external, path=path))))
        #context_items.append((get_string("Convert to mp4"), 'RunPlugin(%s)' % (plugin_url_for(plugin, convert, path=path))))

        items.append({
            'thumbnail': pcon,
            'label': label,
            'path': path,
            'is_playable': True,
            'context_menu': context_items,
            'info_type': 'Video',
            'info':{"title": label, "plot":plot},
        })

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )

    return items


def xml2utc(xml):
    if len(xml) == 14:
        xml = xml + " +0000"
    match = re.search(r'([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2}) ([+-])([0-9]{2})([0-9]{2})', xml)
    if match:
        year = int(match.group(1))
        month = int(match.group(2))
        day = int(match.group(3))
        hour = int(match.group(4))
        minute = int(match.group(5))
        second = int(match.group(6))
        sign = match.group(7)
        hours = int(match.group(8))
        minutes = int(match.group(9))
        dt = datetime(year, month, day, hour, minute, second)
        td = timedelta(hours=hours, minutes=minutes)
        if sign == '+':
            dt = dt - td
        else:
            dt = dt + td
        return dt
    return ''

def find_xml_bytes_encoding(data_bytes):
    data_test_decoding = data_bytes.decode('utf-8', errors='ignore')
    index_end_first_line = data_test_decoding.find('\n')
    match = None
    if index_end_first_line != -1:
        first_line = data_test_decoding[:index_end_first_line]
        match = re.search('<\?xml.*?encoding=["\'](.*?)["\']', first_line, flags=(re.I|re.DOTALL))

    if match:
        encoding = match.group(1)
    else:
        # Improve performance by limiting the detection of the encoding
        # to the first 50k characters if the XML file is bigger
        if len(data_bytes) > 50000:
            chardet_encoding = chardet.detect(data_bytes[:50000])
        else:
            chardet_encoding = chardet.detect(data_bytes)
        encoding = chardet_encoding['encoding']

    return encoding

@plugin.route('/xmltv')
def xmltv():
    load_groups = plugin.get_storage('load_groups')
    load_channels = {}

    dialog = xbmcgui.DialogProgressBG()
    dialog.create("EPG Recorder", get_string("Loading data..."))

    profilePath = xbmcvfs.translatePath(plugin.addon.getAddonInfo('profile'))
    xbmcvfs.mkdirs(profilePath)

    shifts = {}
    streams_to_insert = []
    channels_to_insert = []
    programmes_to_insert = []
    chname2group = {}
    movies2skip = [117,204,208,359,301]
    
    for x in ["1","2"]:
        dialog.update(0, message=get_string("Finding streams"))
        mode = plugin.get_setting('external.m3u.'+x, str)
        if mode == "0":
            if x == "1":
                try:
                    m3uPathType = xbmcaddon.Addon('pvr.iptvsimple').getSetting('m3uPathType')

                    if m3uPathType == "0":
                        path = xbmcaddon.Addon('pvr.iptvsimple').getSetting('m3uPath')
                    else:
                        path = xbmcaddon.Addon('pvr.iptvsimple').getSetting('m3uUrl')
                except:
                    path = ""
            else:
                path = ""
        elif mode == "1":
            path = plugin.get_setting('external.m3u.file.'+x, str)
        else:
            path = plugin.get_setting('external.m3u.url.'+x, str)

        if path:

            m3uFile = 'special://profile/addon_data/plugin.video.epg.recorder/channels'+x+'.m3u'

            xbmcvfs.copy(path, m3uFile)
            f = open(xbmcvfs.translatePath(m3uFile),'rb')
            data = f.read()
            if "m3u8" in path.lower():
                data = data.decode('utf8')
                #log("m3u8")
            else:
                encoding = chardet.detect(data)
                #log(encoding)
                data = data.decode(encoding['encoding'])

            settings_shift = float(plugin.get_setting('external.m3u.shift.'+x, str))
            global_shift = settings_shift

            #log(data)
            data = re.sub('^#EXTGRP:.*?\n', '', data, flags=(re.MULTILINE | re.DOTALL))
            #log(data)

            header = re.search('#EXTM3U(.*)', data)
            if header:
                tvg_shift = re.search('tvg-shift="(.*?)"', header.group(1))
                if tvg_shift:
                    tvg_shift = tvg_shift.group(1)
                    if tvg_shift:
                        global_shift = float(tvg_shift) + settings_shift

            channels = re.findall('#EXTINF:(.*?)(?:\r\n|\r|\n)(.*?)(?:\r\n|\r|\n|$)', data, flags=(re.I | re.DOTALL))
            total = len(channels)
            i = 0
            for channel in channels:
                #log(channel)
                name = None
                if ',' in re.sub('tvg-[a-z]+"[^"]*"','',channel[0], flags=re.I):
                    name = channel[0].rsplit(',', 1)[-1].strip()
                    #name = name.encode("utf8")

                tvg_name = re.search('tvg-name="(.*?)"', channel[0], flags=re.I)
                if tvg_name:
                    tvg_name = tvg_name.group(1) or None
                #else:
                    #tvg_name = name

                tvg_id = re.search('tvg-id="(.*?)"', channel[0], flags=re.I)
                if tvg_id:
                    tvg_id = tvg_id.group(1) or None

                tvg_logo = re.search('tvg-logo="(.*?)"', channel[0], flags=re.I)
                if tvg_logo:
                    tvg_logo = tvg_logo.group(1) or None

                shifts[tvg_id] = global_shift
                tvg_shift = re.search('tvg-shift="(.*?)"', channel[0], flags=re.I)
                if tvg_shift:
                    tvg_shift = tvg_shift.group(1)
                    if tvg_shift and tvg_id:
                        shifts[tvg_id] = float(tvg_shift) + settings_shift

                url = channel[1]
                search = plugin.get_setting('m3u.regex.search', str)
                replace = plugin.get_setting('m3u.regex.replace', str)
                if search:
                    url = re.sub(search, replace, url)

                groups = re.search('group-title="(.*?)"', channel[0], flags=re.I)
                if groups:
                    group = groups.group(1) or None

                streams_to_insert.append((name, tvg_name, tvg_id, tvg_logo, group, url.strip(), i))
                #log(('streams', name, tvg_name, tvg_id, tvg_logo, group, url.strip(), i))
                chname2group[name]=group
                i += 1
                percent = 0 + int(100.0 * i / total)
                dialog.update(percent, message=get_string("Finding streams"))

    xml_filename_to_file_content = {}
    chid2chname = {}
    for x in ["1","2"]:

        mode = plugin.get_setting('external.xmltv.'+x, str)
        if mode == "0":
            if x == "1":
                try:
                    epgPathType = xbmcaddon.Addon('pvr.iptvsimple').getSetting('epgPathType')
                    if epgPathType == "0":
                        path = xbmcaddon.Addon('pvr.iptvsimple').getSetting('epgPath')
                    else:
                        path = xbmcaddon.Addon('pvr.iptvsimple').getSetting('epgUrl')
                except:
                    path = ""
            else:
                path = ""
        elif mode == "1":
            path = plugin.get_setting('external.xmltv.file.'+x, str)
        else:
            path = plugin.get_setting('external.xmltv.url.'+x, str)

        if path:
            xml = os.path.join(profilePath, 'xmltv'+x+'.xml')
            dialog.update(0, message=get_string("Loading channels from xmltv file"))
            #xbmcvfs.copy(path, xml)

            #log((path, xml, epgPathType))
            f = xbmcvfs.File(xml, "rb")
            data_bytes = bytes(f.readBytes())
            f.close()
            magic = data_bytes[:3]
            if magic == b"\x1f\x8b\x08":
                tmp = os.path.join(profilePath, 'xmltv'+x+'.gz')
                xbmcvfs.delete(tmp)
                xbmcvfs.rename(xml, tmp) #Not really useful but it can help for debuging
                dialog.update(0, message=get_string("Unzipping xmltv file"))
                compressedFile = io.BytesIO()
                compressedFile.write(data_bytes)
                compressedFile.seek(0)
                decompressedFile = gzip.GzipFile(fileobj=compressedFile, mode='rb')
                data_bytes = decompressedFile.read()

            encoding = find_xml_bytes_encoding(data_bytes)
            data = data_bytes.decode(encoding)

            xml_filename_to_file_content[xml] = data

            htmlparser = HTMLParser()

            dialog.update(0, message=get_string("Loading xmltv channels"))
            match = re.findall('<channel(.*?)</channel>', data, flags=(re.I|re.DOTALL))
            if match:
                total = len(match)
                log("Loaded %d channels from xmltv." % total, xbmc.LOGINFO)
                match_pattern = re.compile('(id="(.*?)")|(<display-name.*?>(.*?)</display-name)|(<icon.*?src="(.*?)")')

                for m in match:
                    data_found = match_pattern.findall(m)
                    id = None
                    name = None
                    icon = None
                    if data_found:
                        for current_data_found in data_found:
                            if current_data_found[1]:
                                id = htmlparser.unescape(current_data_found[1])
                            elif current_data_found[3]:
                                name = htmlparser.unescape(current_data_found[3])
                            elif current_data_found[5]:
                                icon = current_data_found[5]

                    if id and name:
                        channels_to_insert.append((id, name, icon))
                        #log(('channels', id, name, icon))
                        chid2chname[id]=name
                dialog.update(percent, message=get_string("Loaded %s channels" % total))

    dialog.update(0, message=get_string("Creating database"))
    databasePath = os.path.join(profilePath, 'xmltv.db')
    conn = sqlite3.connect(databasePath, detect_types=sqlite3.PARSE_DECLTYPES)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.execute('DROP TABLE IF EXISTS channels')
    conn.execute('DROP TABLE IF EXISTS streams')
    conn.execute('CREATE TABLE IF NOT EXISTS channels(uid INTEGER PRIMARY KEY ASC, id TEXT, name TEXT, icon TEXT)')
    #TODO unique fails with timestamps: UNIQUE(channelid, channelname, start, stop, description, type)
    conn.execute('CREATE TABLE IF NOT EXISTS rules(uid INTEGER PRIMARY KEY ASC, channelid TEXT, channelname TEXT, title TEXT, sub_title TEXT, start TIMESTAMP, stop TIMESTAMP, date TEXT, description TEXT, episode TEXT, categories TEXT, type TEXT, name TEXT)')
    try: conn.execute('ALTER TABLE rules ADD COLUMN name TEXT')
    except: pass
    #TODO check primary key
    conn.execute('CREATE TABLE IF NOT EXISTS streams(uid INTEGER PRIMARY KEY ASC, name TEXT, tvg_name TEXT, tvg_id TEXT, tvg_logo TEXT, groups TEXT, url TEXT, tv_number INTEGER)')
    conn.execute('CREATE TABLE IF NOT EXISTS favourites(channelname TEXT, channelid TEXT, logo TEXT, PRIMARY KEY(channelname))')
    conn.execute('CREATE TABLE IF NOT EXISTS jobs(uid INTEGER PRIMARY KEY ASC, uuid TEXT, channelid TEXT, channelname TEXT, title TEXT, start TIMESTAMP, stop TIMESTAMP, type TEXT)')

    dialog.update(0, message=get_string("Updating database"))
    conn.executemany("INSERT OR IGNORE INTO streams(name, tvg_name, tvg_id, tvg_logo, groups, url, tv_number) VALUES (?, ?, ?, ?, ?, ?, ?)", streams_to_insert)

    dialog.update(33, message=get_string("Updating database"))
    conn.executemany("INSERT OR IGNORE INTO channels(id, name, icon) VALUES (?, ?, ?)", channels_to_insert)

    dialog.update(66, message=get_string("Updating database"))

    conn.commit()
    conn.close()

    dialog.update(100, message=get_string("Finished loading data"))
    time.sleep(1)
    dialog.close()
    refresh()
    return


@plugin.route('/nuke')
def nuke():
    if not (xbmcgui.Dialog().yesno("IPTV Recorder", get_string("Delete Everything and Start Again?"))):
        return

    xbmcvfs.delete(xbmcvfs.translatePath('%sxmltv.db' % plugin.addon.getAddonInfo('profile')))
    time.sleep(5)
    reload_data()

@plugin.route('/reload_data')
def reload_data():
    status = plugin.get_storage('status')
    status.clear()
    status.sync()
    xmltv()

@plugin.route('/clear_historya')
def clear_history():
    db = plugin.get_storage('recently_played')
    db.clear()
    db.sync()


@plugin.route('/maintenance_index')
def maintenance_index():
    items = []
    context_items = []

    if plugin.get_setting('debug', str) == "true":
        items.append(
        {
            'label': get_string("Reload Data"),
            'path': plugin_url_for(plugin, 'reload_data'),
            'thumbnail':get_icon_path('settings'),
            'context_menu': context_items,
        })

        items.append(
        {
            'label': get_string("Clear cache and disk"),
            'path': plugin_url_for(plugin, 'nuke'),
            'thumbnail':get_icon_path('settings'),
            'context_menu': context_items,
        })

        items.append(
        {
            'label': get_string("Clear history"),
            'path': plugin_url_for(plugin, 'clear_history'),
            'thumbnail':get_icon_path('settings'),
            'context_menu': context_items,
        })

        if xbmc.getCondVisibility('system.platform.android'):
            items.append(
            {
                'label': get_string("Delete ffmpeg"),
                'path': plugin_url_for(plugin, 'delete_ffmpeg'),
                'thumbnail':get_icon_path('settings'),
                'context_menu': context_items,
            })

    return items


def get_free_space_mb(dirname):
    """Return folder/drive free space (in megabytes)."""
    if platform.system() == 'Windows':
        free_bytes = ctypes.c_ulonglong(0)
        ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(dirname), None, None, ctypes.pointer(free_bytes))
        return free_bytes.value / 1024 / 1024
    else:
        try:
            st = os.statvfs(dirname)
            return st.f_bavail * st.f_frsize / 1024 / 1024
        except:
            #log(dirname)
            return
    

@plugin.route('/')
def index():

    items = []
    context_items = []

    items.append(
    {
        'label': "[COLOR orange]Фильмы по жанрам[/COLOR]",
        'path': plugin_url_for(plugin, 'categories'),
        'thumbnail':get_icon_path('folder'),
        'context_menu': context_items,
    })

    items.append(
    {
        'label': "[COLOR green]Recordings[/COLOR]",
        'path': plugin_url_for(plugin, 'recordings'),
        'thumbnail':get_icon_path('recordings'),
        'context_menu': context_items,
    })

    items.append(
    {
        'label': "History",
        'path': plugin_url_for(plugin, 'recently_viewed'),
        'thumbnail':get_icon_path('folder'),
        'context_menu': context_items,
    })

    items.append(
    {
        'label': "",
        'path': plugin_url_for(plugin, 'recordings'),
        'context_menu': context_items,
    })

    items.append(
    {
        'label': get_string("Recordings Folder"),
        'path': plugin.get_setting('recordings', str),
        'thumbnail':get_icon_path('recordings'),
        'context_menu': context_items,
    })

    context_items = []

    items.append(
    {
        'label': get_string("Maintenance"),
        'path': plugin_url_for(plugin, 'maintenance_index'),
        'thumbnail':get_icon_path('settings'),
        'context_menu': context_items,
    })


    free = get_free_space_mb(xbmcvfs.translatePath(plugin.get_setting('recordings', str)))
    if free:
        items.append(
        {
            'label': "[COLOR dimgray]%d MB Free[/COLOR]" % free,
            'path': plugin_url_for(plugin, 'recordings'),
            'thumbnail':get_icon_path('settings'),
            'context_menu': context_items,
        })

    return items


if __name__ == '__main__':
    plugin.run()

    containerAddonName = xbmc.getInfoLabel('Container.PluginName')
    AddonName = xbmcaddon.Addon().getAddonInfo('id')
        
    if containerAddonName == AddonName:

        if big_list_view == True:

            view_mode = int(plugin.get_setting('view.mode', str) or "0")

            if view_mode:
                plugin.set_view_mode(view_mode)
1
