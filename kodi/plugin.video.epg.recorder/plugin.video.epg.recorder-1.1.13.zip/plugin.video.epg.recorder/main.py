# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from xbmcswift2 import Plugin, ListItem
from collections import namedtuple
from datetime import datetime, timedelta, tzinfo, timezone
from language import get_string
from struct import *
from urllib.parse import urlencode, parse_qsl

import urllib.parse
import urllib.request
import base64
import calendar
import chardet
import ctypes
import glob
import io
import json
import os, os.path
import platform
import random
import re
import requests
import shutil
import sqlite3
import stat
import subprocess
import sys
import threading
import time
import xbmcvfs

################################################################################
# Global controls:
REC_ENABLE = 1
CREATE_NFO = 1
RECENT_UPDATE = True
#
################################################################################

EPGDB      = xbmcvfs.translatePath('special://database/Epg13.db')
CHANNELDB  = xbmcvfs.translatePath('special://database/TV38.db')
UTC_ADJUST = timedelta(hours=0)
NFO_SUFFIX = '.nfo'
REC_SUFFIX = '.rec'
POS_SUFFIX = '.pos'


if platform.system() == 'Windows':
    UTC_ADJUST = UTC_ADJUST + timedelta(hours=1)

try:
    from urllib.parse import quote, quote_plus, unquote_plus
    from html import unescape as html_unescape
    from io import StringIO
    class HTMLParser:
        def unescape(self, string):
            return html_unescape(string)
except ImportError:
    from urllib import quote, quote_plus, unquote_plus
    from HTMLParser import HTMLParser
    from StringIO import StringIO

import uuid
from kodi_six import xbmc, xbmcaddon, xbmcvfs, xbmcgui, xbmcplugin
from kodi_six.utils import encode_decode

plugin = Plugin()
big_list_view = True
CHANNEL_SKIPLIST = plugin.get_setting('channel_skiplist', str).split(',')

def addon_id():
    return xbmcaddon.Addon().getAddonInfo('id')

def log(v, type=xbmc.LOGERROR):
    xbmc.log('[EPGRECORDER]: '+repr(v), type)

    
@encode_decode
def plugin_url_for(plugin, *args, **kwargs):
    return plugin.url_for(*args, **kwargs)

def get_icon_path(icon_name):
    return "special://home/addons/%s/resources/img/%s.png" % (addon_id(), icon_name)


def remove_formatting(label):
    label = re.sub(r"\[/?[BI]\]", '', label, flags=re.I)
    label = re.sub(r"\[/?COLOR.*?\]", '', label, flags=re.I)
    return label


def escape( str ):
    str = str.replace("&", "&amp;")
    str = str.replace("<", "&lt;")
    str = str.replace(">", "&gt;")
    str = str.replace("\"", "&quot;")
    return str


def unescape( str ):
    str = str.replace("&lt;", "<")
    str = str.replace("&gt;", ">")
    str = str.replace("&quot;", "\"")
    str = str.replace("&amp;", "&")
    return str


def delete(path):
    dirs, files = xbmcvfs.listdir(path)
    for file in files:
        xbmcvfs.delete(path+file)
    for dir in dirs:
        delete(path + dir + '/')
    xbmcvfs.rmdir(path)

def rmdirs(path):
    path = xbmcvfs.translatePath(path)
    dirs, files = xbmcvfs.listdir(path)
    for dir in dirs:
        rmdirs(os.path.join(path,dir))
    xbmcvfs.rmdir(path)


def find(path):
    path = xbmcvfs.translatePath(path)
    all_dirs = []
    all_files = []
    dirs, files = xbmcvfs.listdir(path)
    for file in files:
        file_path = os.path.join(path,file)
        all_files.append(file_path)
    for dir in dirs:
        dir_path = os.path.join(path,dir)
        all_dirs.append(dir_path)
        new_dirs, new_files = find(os.path.join(path, dir))
        for new_dir in new_dirs:
            new_dir_path = os.path.join(path,dir,new_dir)
            all_dirs.append(new_dir_path)
        for new_file in new_files:
            new_file = os.path.join(path,dir,new_file)
            all_files.append(new_file)
    return all_dirs, all_files

def check_has_db_filled_show_error_message_ifn(db_cursor):
    table_found = db_cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='streams'").fetchone()
    if not table_found:
        xbmcgui.Dialog().notification("IPTV Recorder", get_string("Database not found"))
        return False
    return True


def xml2local(xml):
    #TODO combine
    return utc2local(xml2utc(xml))


def utc2local(utc):
    timestamp = calendar.timegm(utc.timetuple())
    local = datetime.fromtimestamp(timestamp)
    return local.replace(microsecond=utc.microsecond)

def utc2utc(utc):
    timestamp = calendar.timegm(utc.timetuple())
    local = datetime.fromtimestamp(timestamp)
    return local
    
def str2dt(string_date):
    format ='%Y-%m-%d %H:%M:%S'
    try:
        res = datetime.strptime(string_date, format)
    except TypeError:
        res = datetime(*(time.strptime(string_date, format)[0:6]))
    return utc2local(res)

def total_seconds(td):
    return int((td.microseconds + (td.seconds + td.days * 24 * 3600) * 10**6) / 10**6)

def hhmmss2seconds(t):
    seconds = 0
    tl = t.split(':')
    log(tl)
    if len(tl) == 1:
        seconds += int(tl[0])
    if len(tl) == 2:
        seconds += int(tl[0])*60
        seconds += int(tl[1])
    if len(tl) == 3:
        seconds += int(tl[0])*60*60
        seconds += int(tl[0])*60
        seconds += int(tl[1])
    return seconds


def windows():
    if os.name == 'nt':
        return True
    else:
        return False


def android_get_current_appid():
    with open("/proc/%d/cmdline" % os.getpid()) as fp:
        return fp.read().rstrip("\0")



@plugin.route('/record_from_epg_player/<chname>')
def record_from_epg_player(chname):
    title = xbmc.getInfoLabel('VideoPlayer.Title')
    log(('record from player', chname, title))

    channels = get_channel_table()
    url = channels[chname]['url']

    conn = sqlite3.connect(EPGDB, detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    c = conn.cursor()
    idEpg = c.execute('SELECT idEpg FROM epg WHERE sName=?',(chname,)).fetchone()
    try:
        start, stop, plot, thumbnail, sGenre = c.execute('SELECT iStartTime, iEndTime, sPlot, sIconPath, sGenre FROM epgtags WHERE sTitle=? AND idEpg=? AND iEndTime<?',(title,idEpg[0],int(datetime.now().timestamp()))).fetchone()
    except:
        xbmcgui.Dialog().notification("Connot be recorded.", 'Future progarm?',
                                      xbmcgui.NOTIFICATION_ERROR, 10000)
        return

    conn.commit()
    conn.close()
    before = int(plugin.get_setting('minutes.before', str) or "0")
    after  = int(plugin.get_setting('minutes.after', str) or "0")
    start  = datetime.utcfromtimestamp(start)
    stop   = datetime.utcfromtimestamp(stop)
    my_start = start - UTC_ADJUST - timedelta(minutes=before)
    my_start = str(my_start.replace(tzinfo=timezone.utc).timestamp())
    my_stop = stop - UTC_ADJUST + timedelta(minutes=after)
    my_stop = str(my_stop.replace(tzinfo=timezone.utc).timestamp())
    length = str(total_seconds(stop - start))
    if not plot:
        plot = 'plot'
    if not thumbnail:
        thumbnail='thumbnail'
    # Create playing item:
    item=dict()
    item['chname']=chname
    item['url']=url
    item['title']=title
    item['my_start']=my_start
    item['my_stop']=my_stop
    item['length']=length
    item['plot']=plot
    item['picon']=thumbnail
    item['poster']=thumbnail
    item['thumbnail']=thumbnail
    item['genre']=sGenre
    item['ptitle']=purify_title(title)
    item['position'] = hhmmss2seconds(xbmc.getInfoLabel('PVR.EpgEventElapsedTime'))
    tmp = item
    add2history(item)

    tmp = plugin.get_storage('playing')
    tmp.clear()
    tmp.update(item)
    tmp.sync()
    threading.Thread(target=monitor_player_state,args=[item.copy(), 'record']).start()
    record_currently_playing_item()


        
@plugin.route('/record_from_epg_context/<chname>/<tv_number>/<title>/<start>/<stop>')
def record_from_epg_context(chname, tv_number, title, start, stop):

    channels = get_channel_table()
    url = channels[chname]['url']
    before = int(plugin.get_setting('minutes.before', str) or "0")
    after  = int(plugin.get_setting('minutes.after', str) or "0")
    my_start = str2date(start) - timedelta(hours=SUMMERTIME) - timedelta(minutes=before)
    my_stop = str2date(stop) - timedelta(hours=SUMMERTIME) + timedelta(minutes=after)

    length = str(total_seconds(my_stop - my_start))
    my_start = str(datetime2timestamp(my_start))
    my_stop = str(datetime2timestamp(my_stop))

    log(("cal recorder with:", chname, tv_number, url, title, my_start, length))
    # Create playing item:
    item = dict()
    item['chname']=chname
    item['url']=url
    item['title']=title
    item['my_start']=my_start
    item['my_stop']=my_stop
    item['length']=length
    item['plot']=plot
    item['picon']='picon'
    item['poster']='poster'
    item['thumbnail']='thumbnail'
    item['genre']=''
    item['ptitle']=purify_title(title)
    item['position'] = hhmmss2seconds(xbmc.getInfoLabel('PVR.EpgEventElapsedTime'))

    tmp = plugin.get_storage('playing')
    tmp.clear()
    tmp.update(item)
    tmp.sync()
   
    record_currently_playing_item()
    

def add2history(prog):
    #log(('adding prog',prog))
    MAX_RECENTLY_PLAYED = 50
    db = plugin.get_storage('recently_played')
    rec_folder = xbmcvfs.translatePath(plugin.get_setting('rec_folder', str))

    if db.get('rp_list') == None:
        db['rp_list'] = [prog]
    else:
        i=0
        for e in db['rp_list']:
            #log(('testing: ',e))
            if e['title']== prog['title']:
                db['rp_list'].pop(i)
                #log(('removing element', prog))
            i+=1
        if len(db['rp_list']) >= MAX_RECENTLY_PLAYED:
            p = db['rp_list'].pop()
            fname = rec_folder + p['ptitle'] + POS_SUFFIX
            xbmcvfs.delete(fname)

        db['rp_list'].insert(0, prog)
    
    ffrom = xbmcvfs.translatePath(plugin.storage_path + 'recently_played')
    fto   = xbmcvfs.translatePath(plugin.get_setting('rec_folder', str) + 'DB/recently_played')
    #log(('storage:',ffrom, fto))
    xbmcvfs.copy(ffrom, fto)

    return

@plugin.route('/history')
def history():
    db = plugin.get_storage('recently_played')
    rec_folder = xbmcvfs.translatePath(plugin.get_setting('rec_folder', str))

    if plugin.get_setting('ext_history', bool):
        fname = rec_folder + 'DB/recently_played'
        f = xbmcvfs.File(fname, 'rb')
        db.load(f)
        f.close()
        
    if db.get('rp_list') == None:
        return
    
    #log('rp_list length is %s' % len(db['rp_list']))
    log(db['rp_list'])
    items = []
    if len(db['rp_list']) > 0:
        for e in db['rp_list']:
            position = 0
            if 'ptitle' in e:
                fname = rec_folder + e['ptitle'] + POS_SUFFIX
                f = xbmcvfs.File(fname)
                position = f.read()
                f.close()
                if not position:
                    position=0
                    log('Corrupted position file: %s' % fname)

            if e['genre']:
                genre_label = "[COLOR grey] [" + e['genre'] +"][/COLOR]"
            else:
                genre_label= ""
            dictitem = {
                'label': e['title'] + genre_label,
                'path': plugin_url_for(plugin, play_by_url, chname=e['chname'], url=e['url'],
                                       title=e['title'], my_start=e['my_start'], my_stop=e['my_stop'],
                                       length=e['length'], plot=e['plot'],
                                       poster=e['poster'], thumbnail=e['thumbnail'], add2recent=True,
                                       genre=e['genre']),
                #'path': e['url']+now,
                #'thumbnail': thumbnail,
                'info_type': 'video',
                'info':{
                    "title": e['title'],
                    "plot": e['plot'] ,
                    'mediatype':'movie',
                    "originaltitle": e['chname'] + '/' + e['my_start'] + '/' + e['length'], #passed to skin for recording
                }, 
                'is_playable' : True,
                #'context_menu': context_items,
            }

            li = ListItem().from_dict(**dictitem)

            li._listitem.setProperties({
                'StartOffset':position,
                #'StartPercent':100*float(position)/float(e['length']),
            })
            
            li.set_property('inputstream', 'inputstream.ffmpegdirect')
            li.set_property('inputstream.ffmpegdirect.catchup_buffer_start_time', e['my_start'])
            li.set_property('inputstream.ffmpegdirect.catchup_buffer_end_time', e['my_stop'])
            li.set_property('inputstream.ffmpegdirect.catchup_buffer_offset', str(position))
            li.set_property('inputstream.ffmpegdirect.catchup_granularity', str(60))
            li.set_property('inputstream.ffmpegdirect.catchup_terminates', 'true')
            li.set_property('inputstream.ffmpegdirect.catchup_url_format_string',
                                  e['url'] + plugin.get_setting('catchup_url_format_string', str))
            li.set_property('inputstream.ffmpegdirect.default_url', e['url'])
            li.set_property('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            li.set_property('inputstream.ffmpegdirect.manifest_type', 'hls')
            li.set_property('inputstream.ffmpegdirect.playback_as_live', 'false')
            li.set_property('inputstream.ffmpegdirect.stream_mode', 'catchup')
            li.set_property('inputstream.ffmpegdirect.timezone_shift', plugin.get_setting('timezone.shift', str))
            li.set_property('thumbnail', e['thumbnail'])
            li._listitem.setArt({
                "icon": e['thumbnail'],
                "landscape": e['thumbnail'],
                "clearart": e['thumbnail'],
                "clearlogo": e['thumbnail'],
                "thumb": e['thumbnail'],
                "poster": e['poster'],
                "banner": e['thumbnail'],
                "fanart":e['thumbnail']
            })
            items.append(li)
    return plugin.finish(items)
        
    

def sane_name(name):
    if not name:
        return
    if windows() or (plugin.get_setting('filename.urlencode', str) == 'true'):
        name = quote(name.encode('utf-8'))
        name = name.replace("%20",' ')
        name = name.replace('/',"%2F")
    else:
        _quote = {'"': '%22', '|': '%7C', '*': '%2A', '/': '%2F', '<': '%3C', ':': '%3A', '\\': '%5C', '?': '%3F', '>': '%3E'}
        for char in _quote:
            name = name.replace(char, _quote[char])
    return name


def refresh():
    containerAddonName = xbmc.getInfoLabel('Container.PluginName')
    AddonName = xbmcaddon.Addon().getAddonInfo('id')
    if (containerAddonName == AddonName) and (plugin.get_setting('refresh', str) == 'true') :
        xbmc.executebuiltin('Container.Refresh')


def datetime2timestamp(dt):
    epoch=datetime.fromtimestamp(0.0)
    td = dt - epoch
    return (td.microseconds + (td.seconds + td.days * 86400) * 10**6) / 10**6


def timestamp2datetime(ts):
    return datetime.fromtimestamp(ts)


def time2str(t):
    return "%02d:%02d" % (t.hour,t.minute)


def str2time(s):
    return datetime.time(hour=int(s[0:1],minute=int(s[3:4])))


@plugin.route('/category/<title>')
def category(title):

    conn = sqlite3.connect(EPGDB, detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    c = conn.cursor()

    programmes = c.execute('SELECT idEpg, sTitle, iStartTime, iEndTime, iYear , sPlot , sGenre, sIconPath, sCast, sDirector FROM epgtags WHERE sGenre LIKE ? AND iEndTime<? ORDER BY iYear DESC, iStartTime DESC',("%"+title+"%", int(datetime.now().timestamp()))).fetchall()
    # sTitle should be @ position 1 to uniqify later by title
    # sort by DESC order to corrctly uniqify for latest programm

    conn.commit()
    conn.close()

    return (make_list(programmes, mode='movie', scroll=True))


@plugin.route('/sports')
def sports():
    items = []

    sport_categories = plugin.get_setting('sport_groups', str)
    #log(sport_categories)
    sport_categories = sport_categories.split(',')
    
    for cat in sport_categories:
        #log(cat)
        cat = cat.split(':')
        items.append({
            'label': cat[1],
            'path': plugin_url_for(plugin, sport, text=cat[0]),
            'thumbnail': get_icon_path('folder'),
        })

    return items


@plugin.route('/sport/<text>')
def sport(text):

    programmes = []
    texts = text.split('|')

    conn = sqlite3.connect(EPGDB, detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    c = conn.cursor()

    for text in texts:
        #log('extending by %s' % text)
        progs = c.execute('SELECT idEpg, sTitle, iStartTime, iEndTime, iYear , sPlot , sGenre, sIconPath, sCast, sDirector FROM epgtags WHERE sTitle LIKE ? AND iEndTime<? ORDER BY iStartTime DESC, iStartTime DESC',
                          ("%"+text+"%", int(datetime.now().timestamp()))).fetchall()
        #progs = c.execute('SELECT idEpg, sTitle, iStartTime, iEndTime, iYear , sPlot , sGenre, sIconPath, sCast, sDirector FROM epgtags WHERE sTitle LIKE ? ORDER BY iYear DESC, iStartTime DESC',
        #                           ("%"+text+"%", )).fetchall()
        # sTitle should be @ position 1 to uniqify later by title
        # sort by DESC order to corrctly uniqify for latest programm
        #log(programmes)
        if len(progs) > 0:
            #log('extending from %s by %s' % (text, progs))
            programmes.extend(progs)
        
    conn.commit()
    conn.close()

    return make_list(programmes, mode='sport', scroll=True)


def uniqify_programs(programmes):
    res = []
    skip_list = []
    
    for p in programmes:
        #log(p)
        if p[1] in skip_list:
            continue
        else:
            skip_list.append(p[1])
            res.append(p)
            #log("appending " + p[1])
            
    #log(res)
    return res

def get_channel_table():
    channels = {}
    dir = plugin.get_setting('rec_folder', str)
    json_file = dir+'DB/channels.json'
    if xbmcvfs.exists(json_file):
        #log(('Loading channels file', json_file))
        channels = xbmcvfs.File(json_file).read()
        channels = json.loads(channels)
    else:
        log('Unable to load %s' % json_file)
    return channels


def make_list(programmes, mode, scroll=False):

    now = datetime.now()
    programmes = uniqify_programs(programmes)
    #log(programmes)
    conn = sqlite3.connect(EPGDB)
    c = conn.cursor()

    dir = plugin.get_setting('rec_folder', str)
    json_file = dir+'DB/image_lib.json'
    if xbmcvfs.exists(json_file):
        #log(('Loading image lib', json_file))
        img_lib = xbmcvfs.File(json_file).read()
        img_lib = json.loads(img_lib)

    channels = get_channel_table()
    items = []
    for p in programmes:
        idEpg , title , start , stop , date , description , categories, thumbnail, cast, director = p

        if not description:
            description = 'none'

        chname = c.execute('SELECT sName FROM epg WHERE idEPG=?',(idEpg,) ).fetchone()
        chname = str(chname[0])

        if chname in CHANNEL_SKIPLIST:
            continue
        
        if chname in channels:
            url    = channels[chname]['url']
            picon  = channels[chname]['pcon']
        else:
            log(('cannot resolve programm: %s', p))
            continue

        start  = datetime.utcfromtimestamp(start)
        stop   = datetime.utcfromtimestamp(stop)
        #log(('listing:', chname, title, start, categories, picon, description))

        episode = " "

        color = ""
        stitle = "[COLOR %s]%s[/COLOR][COLOR grey]%s[/COLOR]" % (color, title, episode)


        #label = "%02d:%02d-%02d:%02d [COLOR grey]%s/%s[/COLOR] %s %s %s%s (%s)" % (start.hour, start.minute, stop.hour, stop.minute, start.day,
        #                                                                           start.month, channelname_label, categories_label, CR, stitle, date)

        if mode == 'movie':
            label = '['+ str(date) +'] ' + stitle + "[COLOR grey] [" + categories +"] (dtl: %s)[/COLOR]" % (get_remaining_time(start).days)
        else:
            label = stitle + " (dtl: %s)" % (get_remaining_time(start).days)

        context_items = []

        #log(UTC_ADJUST)
        my_start = start - UTC_ADJUST
        my_start = str(my_start.replace(tzinfo=timezone.utc).timestamp())
        my_stop = stop - UTC_ADJUST
        my_stop = str(my_stop.replace(tzinfo=timezone.utc).timestamp())
        length = str(total_seconds(stop - start))
        #now = str(int(datetime2timestamp(datetime.now())))

        #context_items.append(("[COLOR red]%s[/COLOR]" % "Record Programme",
        #                      'RunPlugin(%s)' % (plugin_url_for(plugin, record_by_url, channelname=chname,
        #                                                        url=url,title=title,start=my_start, length=length))))
        
        if not thumbnail:
            thumbnail = picon
        poster = thumbnail

        #log((chname, url, title, my_start, my_stop, length, picon, thumbnail, description))
        if title in img_lib:
            poster    = img_lib[title][0]
            thumbnail = poster
            #log('overriding %s poster %s' % (title, poster))
            if len(img_lib[title]) > 1:
                thumbnail = img_lib[title][1]
                #log('overriding %s thumbnail %s' % (title, thumbnail))

        #log(('call play_by_url: ', chname, url, title,
        #     my_start, my_stop, length, poster,
        #     RECENT_UPDATE, description, thumbnail, categories ))
                
        dictitem = {
            'label': label,
            'path': plugin_url_for(plugin, play_by_url, chname=chname, url=url, title=title,
                                   my_start=my_start, my_stop=my_stop, length=length, poster=poster,
                                   add2recent=RECENT_UPDATE, plot=description, thumbnail=thumbnail, genre=categories),
            'thumbnail': thumbnail,
            'context_menu': context_items,
            'info_type': 'Video',
            'info':{
                "title": title,
                "plot":description,
                "genre":categories,
                "originaltitle":chname + '/' + my_start + '/' + length, #passed to skin for recording
                'director':director,
                'cast':build_cast_list(cast),
                'year':date,
                'mediatype':'movie',
            },
            'is_playable':True,
        }
        li = ListItem().from_dict(**dictitem)
        li._listitem.setArt({
            "icon": thumbnail,
            "landscape": thumbnail,
            "clearart": thumbnail,
            "clearlogo": thumbnail,
            "thumbnail": thumbnail,
            "poster": poster,
            "banner": thumbnail,
            "fanart": thumbnail
        })
        
        li.set_property('inputstream', 'inputstream.ffmpegdirect')
        li.set_property('inputstream.ffmpegdirect.catchup_buffer_start_time', my_start)
        li.set_property('inputstream.ffmpegdirect.catchup_buffer_end_time', my_stop)
        li.set_property('inputstream.ffmpegdirect.catchup_buffer_offset', plugin.get_setting('start.offset', str))
        li.set_property('inputstream.ffmpegdirect.catchup_granularity', str(1))
        li.set_property('inputstream.ffmpegdirect.catchup_terminates', 'true')
        li.set_property('inputstream.ffmpegdirect.catchup_url_format_string',
                        url + plugin.get_setting('catchup_url_format_string', str))
        li.set_property('inputstream.ffmpegdirect.default_url', url)
        li.set_property('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        li.set_property('inputstream.ffmpegdirect.manifest_type', 'hls')
        li.set_property('inputstream.ffmpegdirect.playback_as_live', 'false')
        li.set_property('inputstream.ffmpegdirect.stream_mode', 'catchup')
        li.set_property('inputstream.ffmpegdirect.timezone_shift', plugin.get_setting('timezone.shift', str))

        items.append(li)

    conn.commit()
    conn.close()

    #plugin.add_sort_method('unsorted')
    #plugin.add_sort_method('video_year')
    #plugin.add_sort_method('country')
    #plugin.add_sort_method('artist')
    return items

def build_cast_list(cast):
    cast_list = cast.split(', ')
    #log(cast_list)
    return cast_list

@plugin.route('/play_by_url/<chname>/<url>/<title>/<my_start>/<my_stop>/<length>/<poster>/<add2recent>/<plot>/<thumbnail>/<genre>')
def play_by_url(chname, url, title, my_start, my_stop, length, poster, add2recent, plot, thumbnail, genre):
    log(('play_by_url:', chname, url, title, my_start, my_stop, length, genre, plot))

    item=dict()
    item['chname']=chname
    item['url']=url
    item['title']=title
    item['my_start']=my_start
    item['my_stop']=my_stop
    item['length']=length
    item['plot']=plot
    item['poster']=poster
    item['thumbnail']=thumbnail
    item['genre']=genre
    item['ptitle']=purify_title(title)

    if add2recent=="True":
        add2history(item.copy())

    now = str(int(datetime2timestamp(datetime.now())))
    path = url + "?utc=" + my_start + "&lutc=" + now

    tmp = plugin.get_storage('playing')
    tmp.clear()
    tmp.update(item)
    tmp.sync()
    threading.Thread(target=monitor_player_state,args=[item.copy(), 'play']).start()
    
    plugin.set_resolved_url(path)
    
def purify_filename(fname):
    fname = re.sub(r'(?!%s)[^\w\-_\.]', '', fname)
    fname = re.sub('\.+', '.', fname)
    fname = re.sub('^\.+', '', fname)
    return fname

def purify_title(title):
    title = re.sub('Х/ф ', '', title)
    title = re.sub('М/ф ', '', title)
    title = re.sub('"', '', title)
    title = re.sub(':', '', title)
    title = re.sub('/', '_', title)
    title = re.sub(r'\\', '_', title)
    title = re.sub('(\.\s*$)', '', title)
    return title


@plugin.route('/record_currently_playing_item')
def record_currently_playing_item():
    item = plugin.get_storage('playing')
    log(("actual recording:", item['chname'], item['url'], item['title'],
         item['my_start'], item['length'], item['genre']))
    rec_folder = xbmcvfs.translatePath(plugin.get_setting('rec_folder', str))

    if REC_ENABLE:
        fname = rec_folder + item['ptitle'] + REC_SUFFIX
        if xbmcvfs.exists(fname+'.done'):
            xbmcgui.Dialog().notification("EPG Recorder - Already Recorded", item['title'],
                                          xbmcgui.NOTIFICATION_ERROR, 10000)
        else:
            f = xbmcvfs.File(fname, 'w')
            f.write("$channel = '%s';\n" % item['chname'])
            f.write("$url     = '%s';\n" % item['url'])
            f.write("$title   = '%s';\n" % item['ptitle'])
            f.write("$start   = '%s';\n" % item['my_start'])
            f.write("$now     = '%s';\n" % str(datetime2timestamp(datetime.now())))
            f.write("$length  = '%s';\n1\n" % item['length'])
            f.close()
            
            xbmcgui.Dialog().notification("Recoding Started", item['chname']+': '+item['title'],
                                          xbmcgui.NOTIFICATION_INFO, 10000, sound=False)
            fresh_record = plugin.get_storage('fresh_record')
            fresh_record[item['title']] = True

        if CREATE_NFO:
            fname = rec_folder + item['ptitle'] + NFO_SUFFIX
            if 'position' in item:
                position = item['position']
            else:
                position = xbmc.Player().getTime()
            log('creating NFO_ini with position %s' % position)
            f = xbmcvfs.File(fname, 'w')
            f.write('{"title"      : %s,\n' % json.dumps(item['title']))
            f.write('"poster"      : %s,\n' % json.dumps(item['poster']))
            f.write('"plot"        : %s,\n' % json.dumps(item['plot']))
            f.write('"genre"       : %s,\n' % json.dumps(item['genre']))
            f.write('"progress"    : %s,\n' % json.dumps(100*position/float(item['length'])))
            f.write('"thumbnail"   : %s}\n' % json.dumps(item['thumbnail']))
            f.close()
    return

def get_remaining_time(startime):
    return timedelta(days=7) - (datetime.now() - utc2local(startime))


def monitor_player_state(item, context='play'):
    rec_folder = xbmcvfs.translatePath(plugin.get_setting('rec_folder', str))
    title = item['title']
    length = item['length']
    position = 0
    player = xbmc.Player()
    monitor = xbmc.Monitor()      

    ok_to_update_position = 0
    
    wait_time = 3
    wait_step = 1
    if context=='play':
        while not player.isPlaying() and wait_time > 0:
            if monitor.waitForAbort(wait_step): # Sleep/wait for abort for 5 second.
                xbmc.log("Player monitor thread stopped by abort." , xbmc.LOGERROR)
                break # Abort was requested while waiting. Exit the while loop.
            wait_time -= wait_step

        if not player.isPlaying():
            return              # as no player has started at all
        log('Player monitoring ok. Waited player for %d sec' % (5 - wait_time))

    while not monitor.abortRequested():
        if player.isPlaying():
            ok_to_update_position = True
            if context=='play':
                position = player.getTime()
            else:
                position = hhmmss2seconds(xbmc.getInfoLabel('PVR.EpgEventElapsedTime'))
            #xbmc.log("Playing position: %f" % position, xbmc.LOGERROR)

            if monitor.waitForAbort(5): # Sleep/wait for abort for 5 second.
                xbmc.log("Autostop addon service stopped." , xbmc.LOGERROR)
                break # Abort was requested while waiting. Exit the while loop.
        else:
            break               # Abort on recorder stop

    #log("Playback of %s stopped at %f." % (item['title'], position))
    if context=='record':
        if CREATE_NFO:
            # well, if we get there playback stopped during recording, so we will update the NFO with
            # correct start offset
            log('creating NFO with position %s' % position)
            fname = rec_folder + item['ptitle'] + NFO_SUFFIX
            f = xbmcvfs.File(fname, 'w')
            f.write('{"title"      : %s,\n' % json.dumps(item['title']))
            f.write('"poster"      : %s,\n' % json.dumps(item['poster']))
            f.write('"plot"        : %s,\n' % json.dumps(item['plot']))
            f.write('"genre"       : %s,\n' % json.dumps(item['genre']))
            f.write('"progress"    : %s,\n' % json.dumps(100*position/float(item['length'])))
            f.write('"thumbnail"   : %s}\n' % json.dumps(item['thumbnail']))
            f.close()

    elif ok_to_update_position:
        fname = rec_folder + item['ptitle'] + POS_SUFFIX
        f = xbmcvfs.File(fname, 'w')
        f.write('%d' % int(position))
        f.close()
        #log('updating position in recently_played entry %s by %f' % (item['ptitle'], position))
        

def focus(i):
    #TODO find way to check this has worked (clist.getSelectedPosition returns -1)
    xbmc.sleep(int(plugin.get_setting('scroll.ms', str) or "0"))
    #TODO deal with hidden ..
    win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    cid = win.getFocusId()
    if cid:
        clist = win.getControl(cid)
        if clist:
            try: clist.selectItem(i)
            except: pass

@plugin.route('/categories')
def categories():
    items = []

    conn = sqlite3.connect(EPGDB)
    c = conn.cursor()

    titles = c.execute("SELECT DISTINCT sGenre FROM epgtags ORDER BY sGenre").fetchall()

    cats = set()
    for title in titles:
        programme_categories = title[0]
        cats.add(programme_categories)
        programme_categories = programme_categories.split(', ')
        for cat in programme_categories:
            if cat:
                cats.add(cat)
    cats = sorted(list(cats))

    for cat in cats:
        if not cat or ',' in cat:
            continue
        label = cat
        title = cat

        items.append({
            'label': label,
            'path': plugin_url_for(plugin, category, title=title),
            'thumbnail': get_icon_path('folder'),
        })
    conn.commit()
    conn.close()

    return items


@plugin.route('/delete_recording/<label>/<path>')
def delete_recording(label, path):
    if not (xbmcgui.Dialog().yesno("IPTV Recorder", "[COLOR red]" + get_string("Delete Recording?") + "[/COLOR]\n" + label)):
        return
    if not xbmcvfs.delete(path):
        return
    length = int(len('.' + plugin.get_setting('ffmpeg.ext', str)))
    xbmcvfs.delete(path[:-length]+NFO_SUFFIX)
    xbmcvfs.delete(path[:-length]+POS_SUFFIX)
    xbmcvfs.delete(path[:-length]+REC_SUFFIX+'.done')
    refresh()


@plugin.route('/delete_all_recordings')
def delete_all_recordings():
    result = xbmcgui.Dialog().yesno("IPTV Recorder", "[COLOR red]" + get_string("Delete All Recordings?") + "[/COLOR]")
    if not result:
        return

    dir = plugin.get_setting('rec_folder', str)
    dirs, files = find(dir)
    for file in sorted(files):
        if file.endswith('.' + plugin.get_setting('ffmpeg.ext', str)):
            success = xbmcvfs.delete(file)
            if success:
                length = int(len('.' + plugin.get_setting('ffmpeg.ext', str)))
                json_file = file[:-length]+'.json'
                xbmcvfs.delete(json_file)

    rmdirs(dir)
    refresh()


def find_files(root):
    dirs, files = xbmcvfs.listdir(root)
    found_files = []
    for dir in dirs:
        path = os.path.join(xbmcvfs.translatePath(root), dir)
        found_files = found_files + find_files(path)
    file_list = []
    for file in files:
        if file.endswith('.' + plugin.get_setting('ffmpeg.ext', str)):
            file = os.path.join(xbmcvfs.translatePath(root), file)
            file_list.append(file)
    return found_files + file_list


@plugin.route('/recordings')
def recordings():
    dir = plugin.get_setting('rec_folder', str)
    found_files = find_files(dir)

    items = []
    starts = []
    
    fresh_record = plugin.get_storage('fresh_record')
    #log(fresh_record.raw_dict())
    json_file = dir+'DB/image_lib.json'
    if xbmcvfs.exists(json_file):
        #log(('Loading image lib', json_file))
        try:
            img_lib = xbmcvfs.File(json_file).read()
            img_lib = json.loads(img_lib)
        except:
            log('Unable to load image library file: %s' % json_file)
            
    for path in found_files:
        json_file = path[:-3]+NFO_SUFFIX
        resumetime = 0
        label = os.path.splitext(os.path.basename(path))[0]
        label = unquote_plus(label)
        title = label
        plot = "Настенька, запись еще не окончилась. Ты можешь смотреть, но когда остановится - включи заново..."
        pcon = "None"
        thumbnail = pcon
        poster=""
        genre=""
        progress=0
        #log(('Recording: ', json_file))
        if xbmcvfs.exists(json_file):
            try:
                info = json.loads(xbmcvfs.File(json_file).read())
            except:
                log('Unable to load recording file %s' % json_file)
                continue
            title = info.get('title')
            pcon  = info.get('pcon')
            plot  = info.get('plot')
            genre = info.get('genre')
            thumbnail = info.get('thumbnail', None)
            label = title
            poster   = info.get('poster', None)
            progress = info.get('progress', 0)
            
        if title in img_lib:
            poster = img_lib[title][0]
            #log('overriding %s poster' % title)
            if len(img_lib[title]) > 1:
                thumbnail = img_lib[title][1]
                #log('overriding %s thumbnail' % title)

            
        context_items = []

        context_items.append((get_string("Delete Recording"), 'RunPlugin(%s)' % (plugin_url_for(plugin, delete_recording, label=label, path=path))))
        #context_items.append((get_string("Delete All Recordings"), 'RunPlugin(%s)' % (plugin_url_for(plugin, delete_all_recordings))))
        if genre:
            genre_label = "[COLOR grey] [" + genre +"][/COLOR]"
        else:
            genre_label= ""

        dictitem = {
            'label': label + genre_label,
            'path': plugin_url_for(plugin, play_recording, path=path, title=title),
            'thumbnail': thumbnail,
            'context_menu': context_items,
            'info':{
                "title": title,
                "plot": plot,
                "genre":genre,
                'mediatype':'movie',
            },
            'is_playable':True,
        }

        if title in fresh_record:
            dictitem['info']['playcount'] = 1
        
        li = ListItem().from_dict(**dictitem)
        li._listitem.setArt({
            "icon": thumbnail,
            "landscape": thumbnail,
            "clearart": thumbnail,
            "clearlogo": thumbnail,
            "thumbnail": thumbnail,
            "poster": poster,
            "banner": thumbnail,
            "fanart":thumbnail
        })

        #log('Displaying recording %s' % title)
        if title in fresh_record:
            li._listitem.setProperties({
                #'StartOffset':fresh_record[title],
                'StartPercent':progress,
            })
            #log('%s start offset adjusted to %s' % (title, progress))
            
        items.append(li)
    return plugin.finish(items)

@plugin.route('/play_recording/<path>/<title>')
def play_recording(path, title):
    fresh_record = plugin.get_storage('fresh_record')
    if title in fresh_record:
        #log("playing from saved position")
        del fresh_record[title]
    plugin.set_resolved_url(path)

    

def xml2utc(xml):
    if len(xml) == 14:
        xml = xml + " +0000"
    match = re.search(r'([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2}) ([+-])([0-9]{2})([0-9]{2})', xml)
    if match:
        year = int(match.group(1))
        month = int(match.group(2))
        day = int(match.group(3))
        hour = int(match.group(4))
        minute = int(match.group(5))
        second = int(match.group(6))
        sign = match.group(7)
        hours = int(match.group(8))
        minutes = int(match.group(9))
        dt = datetime(year, month, day, hour, minute, second)
        td = timedelta(hours=hours, minutes=minutes)
        if sign == '+':
            dt = dt - td
        else:
            dt = dt + td
        return dt
    return ''


@plugin.route('/on_playback_stop/<cur>/<total>')
def on_playback_stop(cur, total=1000):
    log(("on_playback_stop called", cur, total))
    return

@plugin.route('/clear_history')
def clear_history():
    db = plugin.get_storage('recently_played')
    db.clear()
    db.sync()
    fresh_record = plugin.get_storage('fresh_record')
    fresh_record.clear()
    fresh_record.sync()

@plugin.route('/maintenance_index')
def maintenance_index():
    items = []
    context_items = []

    items.append(
        {
            'label': get_string("Clear history and Rec positions"),
            'path': plugin_url_for(plugin, 'clear_history'),
            'thumbnail':get_icon_path('settings'),
            'context_menu': context_items,
        })

    return items


def get_free_space_mb(dirname):
    """Return folder/drive free space (in megabytes)."""
    if platform.system() == 'Windows':
        free_bytes = ctypes.c_ulonglong(0)
        ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(dirname), None, None, ctypes.pointer(free_bytes))
        return free_bytes.value / 1024 / 1024
    else:
        try:
            st = os.statvfs(dirname)
            return st.f_bavail * st.f_frsize / 1024 / 1024
        except:
            #log(dirname)
            return
    

@plugin.route('/')
def index():

    items = []
    context_items = []

    items.append(
    {
        'label': "[COLOR orange]Фильмы по жанрам[/COLOR]",
        'path': plugin_url_for(plugin, 'categories'),
        'thumbnail':get_icon_path('folder'),
        'context_menu': context_items,
    })

    items.append(
    {
        'label': "[COLOR green]Recordings[/COLOR]",
        'path': plugin_url_for(plugin, 'recordings'),
        'thumbnail':get_icon_path('recordings'),
        'context_menu': context_items,
    })

    items.append(
    {
        'label': "History",
        'path': plugin_url_for(plugin, 'history'),
        'thumbnail':get_icon_path('folder'),
        'context_menu': context_items,
    })

    items.append(
    {
        'label': "Sport [COLOR gray](experimental)[/COLOR]",
        'path': plugin_url_for(plugin, 'sports'),
        'thumbnail':get_icon_path('folder'),
        'context_menu': context_items,
    })



    if plugin.get_setting('debug', bool):

        items.append(
            {
                'label': "",
                'path': plugin_url_for(plugin, 'recordings'),
                'context_menu': context_items,
            })

        items.append(
            {
                'label': get_string("Recordings Folder"),
                'path': plugin.get_setting('rec_folder', str),
                'thumbnail':get_icon_path('recordings'),
                'context_menu': context_items,
            })

        items.append(
            {
                'label': get_string("Maintenance"),
                'path': plugin_url_for(plugin, 'maintenance_index'),
                'thumbnail':get_icon_path('settings'),
                'context_menu': context_items,
            })
        
    free = get_free_space_mb(xbmcvfs.translatePath(plugin.get_setting('rec_folder', str)))
    if free:
        items.append(
        {
            'label': "[COLOR dimgray]%d MB Free[/COLOR]" % free,
            'path': plugin_url_for(plugin, 'recordings'),
            'thumbnail':get_icon_path('settings'),
            'context_menu': context_items,
        })

    return items


if __name__ == '__main__':
    plugin.run()

    containerAddonName = xbmc.getInfoLabel('Container.PluginName')
    AddonName = xbmcaddon.Addon().getAddonInfo('id')
    #plugin.set_content('videos') ->otherwise issues with undefined handle
    
    # if containerAddonName == AddonName:

    #     if big_list_view == True:

    #         view_mode = int(plugin.get_setting('view.mode', str) or "0")

    #         if view_mode:
    #             plugin.set_view_mode(view_mode)

1
