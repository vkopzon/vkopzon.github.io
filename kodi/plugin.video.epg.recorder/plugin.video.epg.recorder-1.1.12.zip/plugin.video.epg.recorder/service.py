import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
from common import settings, playCount, sleepNotify, stopPlayback, translate

pos = 0
count = 0 
pacount = 0
plcount = 0
extime = 0
padjust = settings('padjust')
plstoptime = int(settings('plstop'))
plnotify = int(settings('plnotify'))
plextend = int(settings('plextend'))
settings('extime', '0')
asevlog = settings('asevlog')
settings('notifyset', 'no')
settings('varextnotify', 'no')

xbmc.log("Autostop addon service started." , xbmc.LOGINFO)

class XBMCPlayer(xbmc.Player):
    
    def __init__(self, *args):
        self.position = 0
        self.total = 0
        pass

    def onPlayBackStarted(self):
        #xbmc.log("Autostop playback started" , xbmc.LOGERROR)
        #xbmcgui.Dialog().notification("onPlayBackStarted", 'Vlad', xbmcgui.NOTIFICATION_ERROR, 2000)
        self.total = player.getTotalTime()
        xbmc.log(self.title, xbmc.LOGERROR)
        return

    def onPlayBackPaused(self):
        #xbmc.log("Autostop playback paused" , xbmc.LOGDEBUG)
        return
    
    def onPlayBackResumed(self):
        #xbmc.log("Autostop playback resumed" , xbmc.LOGDEBUG)
        self.paflag = 0
        self.plflag = 1
        return
    
    def onPlayBackEnded(self):
        xbmc.log("Autostop playback ended" , xbmc.LOGERROR)
        #xbmcgui.Dialog().notification("onPlayBackEnded", 'Vlad', xbmcgui.NOTIFICATION_ERROR, 2000)
        return
    
    def onPlayBackStopped(self):
        #xbmc.log("Autostop playback stopped" , xbmc.LOGERROR)
        #xbmcgui.Dialog().notification("onPlayBackStopped", 'Vlad', xbmcgui.NOTIFICATION_ERROR, 2000)
        xbmc.executebuiltin(
            "PlayMedia(plugin://plugin.video.epg.recorder/on_playback_stop/%f/%f)" % (self.position, self.total)
        )

             
player = XBMCPlayer()
 
monitor = xbmc.Monitor()      
 
while not monitor.abortRequested():

    if player.isPlaying():
        player.position = player.getTime()
        #xbmc.log("Playing position: %f" % player.position, xbmc.LOGERROR)

    if monitor.waitForAbort(5): # Sleep/wait for abort for 1 second.
        xbmc.log("Autostop addon service stopped." , xbmc.LOGINFO)
        break # Abort was requested while waiting. Exit the while loop.


